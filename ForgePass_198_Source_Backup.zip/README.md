# Forge Pass — 198 crisp branching artworks

99 Preview (IDs 001–099), 66 Motion (100–165), 33 Volumetric (166–198).
198 PNG masters at 2048×2048; 99 GIF animations at 1000×1000, 20 fps.
Motion loops last 24 seconds. Volumetric loops last 12 seconds.
Each GIF remains below 50,000,000 bytes. No MP4 exports are required.

The approved cyan circuit-branch aesthetic is retained: five angular arms,
tapered rails with dark extrusion, restrained highlights, terminal lights,
segmented rings, navy background, and a fixed faceted hub. Eleven structural
profiles vary actual branching, proportions, density, and fork placement.
Every artwork has its own seeded geometry and geometry fingerprint.

Rendering uses Skia antialiased vector rasterization with Pillow compositing.
The approved Pillow drawing primitives are preserved in source/approved_style.py.
This is a procedural 2.5D artwork pipeline; Blender is not required.
The animation's depth comes from layered front/rear geometry, extrusion shading,
and controlled separation/merging, not a physically simulated volume.

## Rebuild (optional)

Requires Python 3.12 and FFmpeg on PATH. Create an isolated environment or install
local dependencies with `python -m pip install --target vendor -r requirements.txt`.
From this folder:

    python source/build_collection.py
    python source/produce.py stills --workers 4
    python source/produce.py animations --workers 4
    python source/validate_collection.py
    python source/package_collection.py

Rendering resumes from completed, hash-verified reports. Intermediate frames
are removed after validated GIF encoding. The exported global GIF palette uses
up to 256 colors; 192 or 128 is tried only when needed to fit the 50 MB limit.
Dithering is disabled to keep the dark background and fine rails clean.

Collection.json contains all 198 geometry definitions, seeds, tiers, and paths.
Validation.json contains media SHA256 hashes, sizes, full-frame GIF checks,
loop endpoint checks, hub stability, and connected-branch checks.
Contact sheets are review aids, not additional NFT editions.

These exports are art deliverables. They have not been minted or uploaded to
OpenSea. NFT media hosting, token metadata, and contract deployment are separate
steps; no permanent media URIs or deployed contracts are claimed here.
