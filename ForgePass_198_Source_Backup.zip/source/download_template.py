"""Download and verify the full Forge Pass collection using Python 3 (no packages needed)."""
from pathlib import Path
import hashlib,json,urllib.request,zipfile,shutil,time
ARCHIVES = []  # Replaced with the final, verified archive inventory during packaging.
ROOT=Path(__file__).resolve().parent/'ForgePass_198_Collection'
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def main():
 ROOT.mkdir(exist_ok=True)
 for index,archive in enumerate(ARCHIVES,1):
  members=archive['artworks']
  if all((ROOT/m['artifact']).is_file() and sha(ROOT/m['artifact'])==m['sha256'] for m in members):
   print(f"[{index}/{len(ARCHIVES)}] Already verified: {archive['filename']}",flush=True);continue
  dest=ROOT/archive['filename'];part=dest.with_suffix('.download')
  if not(dest.is_file() and sha(dest)==archive['sha256']):
   print(f"[{index}/{len(ARCHIVES)}] Downloading {archive['filename']} ({archive['bytes']/1e6:.1f} MB)",flush=True)
   for attempt in range(3):
    try:
     request=urllib.request.Request(archive['url'],headers={'User-Agent':'ForgePass-Collection-Downloader'})
     with urllib.request.urlopen(request,timeout=120) as response,part.open('wb') as out:shutil.copyfileobj(response,out)
     if part.stat().st_size!=archive['bytes'] or sha(part)!=archive['sha256']:raise ValueError('Download checksum mismatch')
     part.replace(dest);break
    except Exception:
     if attempt==2:raise
     time.sleep(2)
  expected={m['artifact']:m for m in members}
  with zipfile.ZipFile(dest) as z:
   if set(z.namelist())!=set(expected) or z.testzip() is not None:raise ValueError('Archive integrity mismatch')
   for name,member in expected.items():
    target=(ROOT/name).resolve()
    if ROOT.resolve() not in target.parents:raise ValueError('Unsafe archive path')
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
     if sha(target)==member['sha256']:continue
     raise FileExistsError(f'Preserving a different existing file: {target}')
    temp=target.with_suffix(target.suffix+'.download')
    with z.open(name) as src,temp.open('wb') as out:shutil.copyfileobj(src,out)
    if sha(temp)!=member['sha256']:raise ValueError(f'Artwork checksum mismatch: {name}')
    temp.replace(target)
  dest.unlink() # Only this verified, downloaded temporary archive; artwork is retained.
 pngs=sum(m['artifact'].endswith('.png') for a in ARCHIVES for m in a['artworks']);gifs=sum(m['artifact'].endswith('.gif') for a in ARCHIVES for m in a['artworks'])
 print(f'Complete: {pngs} PNGs and {gifs} GIFs verified in {ROOT}',flush=True)
if __name__=='__main__':
 try:main()
 except Exception as error:print(f'Download stopped: {error}. Run again to resume.');raise
