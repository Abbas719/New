#!/usr/bin/env python3
"""Forge Pass Volumetric: native sculpted circuit bloom, direct lossless export.

All geometry is generated mathematically. No input artwork is edited.
12 seconds, 20 fps. GIF frames are palette-mapped from native-rendered PNGs.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import multiprocessing
import os
import subprocess
import time

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

OUT=Path(__file__).resolve().parent
SIZE=1280
SS=2
SCALE=1.08
NATIVE=SIZE*SS
CX=CY=SIZE/2
FPS=20
SECONDS=12
COUNT=FPS*SECONDS
TAU=2*math.pi
SEED=850199
ARM_ANGLES=[-92,-20,52,124,196]
os.environ.setdefault('OMP_NUM_THREADS','2')


def polar(r, a):
    return np.array([math.cos(a), math.sin(a)], dtype=np.float64) * r

def geometry(seed, angles, factor=1.0):
    """Angular, reproducible tree paths: shared trunks and bifurcating twigs."""
    rng = np.random.default_rng(seed)
    paths, tips = [], []
    for arm, deg in enumerate(angles):
        a = math.radians(deg)
        skew = rng.uniform(-0.065, 0.065)
        p0 = polar(58, a)
        p1 = polar(181, a + skew)
        p2 = polar(286, a + skew + rng.uniform(-0.10, 0.10))
        p3 = polar(396, a + skew + rng.uniform(-0.12, 0.12))
        p4 = polar(448, a + skew + rng.uniform(-0.16, 0.16))
        trunk = [p0, p1, p2, p3, p4]
        paths.append((np.array(trunk) * factor, 3.0, arm))
        tips.append(p4 * factor)
        # Offshoots share exact parent nodes rather than floating nearby.
        for j, parent in enumerate([p1, p2, p3]):
            for side in [-1, 1]:
                a2 = a + side * (0.51 - 0.10*j) + rng.uniform(-.07, .07)
                length = [108, 106, 64][j] * rng.uniform(.88, 1.10)
                q1 = parent + polar(length, a2)
                if j == 2:
                    # The outer forks end in one outward segment.  Pulling a
                    # later endpoint inward to a clipping radius would create
                    # tiny backward hooks and folded triangles at these tips.
                    paths.append((np.array([parent, q1]) * factor, 1.7, arm))
                    tips.append(q1 * factor)
                    continue
                if np.linalg.norm(q1) > 440:
                    q1 *= 440 / np.linalg.norm(q1)
                a3 = a2 + side * .27
                q2 = q1 + polar([82, 73, 38][j], a3)
                if np.linalg.norm(q2) > 475:
                    q2 *= 475 / np.linalg.norm(q2)
                paths.append((np.array([parent, q1, q2]) * factor, 1.9, arm))
                tips.append(q2 * factor)
                if j < 2:
                    twig = q1 + polar(61 - j*7, a2 - side*.49)
                    paths.append((np.array([q1, twig]) * factor, 1.35, arm))
                    tips.append(twig * factor)
    return paths, tips

def motion_parameters(frame_number):
    phase=(frame_number % COUNT)/COUNT
    opening=.5+.5*math.sin(TAU*phase)
    fore_scale=.78+.19*opening
    main_radius=405+108*opening
    return {
        'phase':phase,'opening':opening,
        'front_scale':fore_scale,'front_radial_offset':35*opening,
        'front_hinge':4*opening,
        'rear_scale':fore_scale-.12*opening,'rear_radial_offset':7*opening,
        'rear_hinge':-opening,
        'main_halo_radius':main_radius,'inner_halo_radius':main_radius-65*opening,
    }

def moved(p,scale,angle,offset):
    a=math.radians(angle)
    co,si=math.cos(a),math.sin(a)
    p=p*scale
    return np.array([co*p[0]-si*p[1],si*p[0]+co*p[1]])+np.array(offset)

def sector_point(q,arm,params,prefix):
    sign=-1 if arm%2==0 else 1
    angle=sign*params[prefix+'_hinge']
    offset=polar(params[prefix+'_radial_offset'],math.radians(ARM_ANGLES[arm]+angle))
    return moved(q,params[prefix+'_scale'],angle,offset)

def sector_geometry(params,prefix):
    paths=[];feeders=[]
    for path,width,arm in FRONT:
        moved_path=np.array([sector_point(q,arm,params,prefix) for q in path])
        paths.append((moved_path,width,arm))
        # Native telescoping feeders attach the rigid fan roots to fixed hub.
        if width>2.5:
            q=moved_path[0];r=np.linalg.norm(q)
            if r>63:
                feeders.append((np.array([q/r*63,q]),3.,arm))
    paths.extend(feeders)
    tips=[sector_point(q,arm,params,prefix) for q,arm in zip(FRONT_TIPS,TIP_ARMS)]
    return paths,tips


def coord(p, offset=(0,0)):
    p=(np.asarray(p)+np.asarray(offset))*SCALE
    return tuple((p+np.array([CX,CY]))*SS)


def line(d,pts,fill,width,offset=(0,0)):
    d.line([coord(p,offset) for p in pts],fill=fill,
           width=max(1,round(width*SS*SCALE)),joint='curve')


def circle(d,p,r,fill,outline=None,width=1,offset=(0,0)):
    x,y=coord(p,offset);r=r*SS*SCALE
    d.ellipse((x-r,y-r,x+r,y+r),fill=fill,outline=outline,
              width=max(1,round(width*SS*SCALE)))


def ribbon_edges(path,widths):
    """Tapered polygon with bounded miter joins and exact shared branch nodes."""
    dirs=np.diff(path,axis=0)
    dirs/=np.linalg.norm(dirs,axis=1)[:,None]
    normals=np.stack([-dirs[:,1],dirs[:,0]],axis=1)
    sides=[]
    for i,p in enumerate(path):
        if i==0: n=normals[0]
        elif i==len(path)-1:n=normals[-1]
        else:
            n=normals[i-1]+normals[i]
            n/=np.linalg.norm(n)
            n=n/max(.6,np.dot(n,normals[i]))
        sides.append(n*widths[i]/2)
    sides=np.array(sides)
    return path+sides,path-sides


def rail(d,path,width,arm,layer='front',offset=(0,0)):
    primary=width>2.5
    secondary=width>=1.7
    if layer=='rear':
        w=3.6 if primary else (2.0 if secondary else 1.2)
        line(d,path,(6,86,159),w+1.5,offset)
        line(d,path,(13,137,218),w,offset)
        if primary: line(d,path,(63,174,233),.7,offset)
        return
    w=15.6 if primary else (6.4 if secondary else 2.9)
    if len(path)==2 and primary: w=12.5
    ws=np.linspace(w,w*(.58 if primary else .7),len(path))
    left,right=ribbon_edges(path,ws)
    points=np.concatenate([left,right[::-1]])
    # Extrusion is displaced down and right; the face occludes the blue plane.
    d.polygon([coord(p,(offset[0]+3.0,offset[1]+5.5)) for p in points],fill=(1,26,49))
    d.polygon([coord(p,offset) for p in points],fill=(2,63,92))
    face_left,face_right=ribbon_edges(path,ws*.72)
    color=(8,156,194) if primary else ((6,149,192) if secondary else (13,169,207))
    d.polygon([coord(p,offset) for p in np.concatenate([face_left,face_right[::-1]])],fill=color)
    # Highlight whichever physical edge faces the common upper-left light.
    for i,(a,b) in enumerate(zip(path[:-1],path[1:])):
        v=b-a;n=np.array([-v[1],v[0]])/np.linalg.norm(v)
        edge=face_left if np.dot(n,[-.707,-.707])>0 else face_right
        line(d,[edge[i],edge[i+1]],(126,233,247) if primary else (55,210,232),
             1.55 if primary else .85,offset)
    if primary:
        line(d,path,(10,105,143),1.5,offset)
        # Recessed fastening collars identify the primary rail as a solid body.
        for p in path[1:-1]:
            circle(d,p,4.1,(3,57,84),offset=offset)
            circle(d,p,2.3,(47,196,223),offset=offset)
            circle(d,p,1.0,(167,244,253),offset=offset)


def segmented_halo(d,r,layer='front'):
    def arc(radius,width,col,angle,span,offset=(0,0)):
        x,y=coord([0,0],offset);rr=radius*SS*SCALE
        d.arc((x-rr,y-rr,x+rr,y+rr),angle,angle+span,fill=col,
              width=max(1,round(width*SS*SCALE)))
    for i in range(10):
        a=3+i*36
        if layer=='rear':
            arc(r,2.6,(12,108,187),a,28)
            arc(r-.8,.7,(30,158,220),a,28)
        else:
            arc(r+1,12.5,(1,24,45),a,28,(3,5.5))
            arc(r,11,(2,68,101),a,28)
            mid=math.radians(a+14)
            light=(1+math.cos(mid-math.radians(225)))*.5
            arc(r-1.8,7.0,(5,int(143+31*light),int(189+22*light)),a,28)
            arc(r-2.0,1.4,(int(70+60*light),int(209+26*light),int(233+14*light)),a,28)
            arc(r-8.0,1.0,(4,95,143),a,28)


def render_hub():
    hub=Image.new('RGB',(NATIVE,NATIVE))
    mask=Image.new('L',(NATIVE,NATIVE))
    d=ImageDraw.Draw(hub);m=ImageDraw.Draw(mask)
    circle(m,[0,0],82,255)
    circle(d,[0,0],82,(2,22,39))
    # Shaded circular planes, without blurred rims or translucent circuitry.
    for r in range(80,0,-1):
        t=1-r/80
        circle(d,[-1.7,-2.4],r,(int(5+8*t),int(37+15*t),int(58+17*t)))
    for r,w,col in [(79,3,(10,85,114)),(75,1,(124,226,242)),
                    (68,7,(3,24,42)),(62,3,(3,126,172)),
                    (52,8,(4,77,109)),(47,1.5,(75,220,239)),
                    (37,6,(2,26,44)),(30,5,(17,172,204))]:
        circle(d,[0,0],r,None,col,w)
    for deg in range(0,360,72):
        p=polar(68,math.radians(deg-18))
        circle(d,p,3.8,(3,23,37));circle(d,p,1.6,(61,171,194))
    # Solid faceted energy core, lit from the upper left.
    vertices=[polar(24,math.radians(30+i*60)) for i in range(6)]
    d.polygon([coord(p) for p in vertices],fill=(15,175,202))
    for i in range(6):
        cols=[(76,216,231),(10,141,177),(6,107,150),
              (26,170,199),(166,243,250),(111,231,243)]
        d.polygon([coord([0,0]),coord(vertices[i]),coord(vertices[(i+1)%6])],fill=cols[i])
    circle(d,[-3,-4],5,(207,253,255))
    return hub,mask


def background():
    yy,xx=np.mgrid[:NATIVE,:NATIVE].astype(np.float32)
    rr=np.sqrt((xx-NATIVE/2)**2+(yy-NATIVE/2)**2)/(NATIVE/2)
    lum=np.clip(1-rr,0,1)
    data=np.zeros((NATIVE,NATIVE,3),dtype=np.uint8)
    for c,(floor,extra) in enumerate([(5,3),(9,6),(15,9)]):
        data[:,:,c]=floor+extra*lum
    bg=Image.fromarray(data);d=ImageDraw.Draw(bg)
    circle(d,[0,0],548,None,(5,36,53),.65)
    for deg in range(0,360,12):
        a=math.radians(deg)
        line(d,[polar(545,a),polar(550,a)],(10,58,78),1.0)
    return bg


def initialize():
    global FRONT,FRONT_TIPS,TIP_ARMS,BG,HUB,HUB_MASK
    FRONT,FRONT_TIPS=geometry(SEED,ARM_ANGLES)
    TIP_ARMS=[i//(len(FRONT_TIPS)//5) for i in range(len(FRONT_TIPS))]
    BG=background();HUB,HUB_MASK=render_hub()


def render_native(frame_number):
    p=motion_parameters(frame_number)
    frame=BG.copy();d=ImageDraw.Draw(frame)
    rear_paths,rear_tips=sector_geometry(p,'rear')
    fore_paths,fore_tips=sector_geometry(p,'front')
    # Rear drawing gets a visible bevel-sized line, yet remains subordinate.
    for path,w,arm in rear_paths:rail(d,path,w,arm,'rear')
    for pt in rear_tips:circle(d,pt,2.8,(22,139,205))
    segmented_halo(d,p['inner_halo_radius'],'rear')
    # Draw primary bodies first so the attached offshoots cover their junctions.
    for path,w,arm in sorted(fore_paths,key=lambda x:-x[1]):rail(d,path,w,arm)
    for pt in fore_tips:
        circle(d,pt,4.5,(2,47,69),offset=(1.8,2.7))
        circle(d,pt,4.0,(3,110,148));circle(d,pt,2.4,(82,220,237))
        circle(d,pt,1.0,(196,248,252))
    segmented_halo(d,p['main_halo_radius'])
    frame=Image.composite(HUB,frame,HUB_MASK)
    # Restrained bloom: only bright emission contributes; no foggy background.
    emission=frame.point(lambda v:max(0,v-125)*.20)
    glow=emission.filter(ImageFilter.GaussianBlur(2.1*SS*SCALE))
    return ImageChops.add(frame,glow)


def render(frame_number,size=1000):
    return render_native(frame_number).resize((size,size),Image.Resampling.LANCZOS)


def preview():
    OUT.mkdir(parents=True,exist_ok=True)
    poses=[(180,'Compact'),(0,'Half open'),(60,'Fully open')]
    sheet=Image.new('RGB',(1536,540),(5,9,15));d=ImageDraw.Draw(sheet)
    thumbs=[]
    for j,(i,label) in enumerate(poses):
        native=render_native(i)
        native.resize((2048,2048),Image.Resampling.LANCZOS).save(OUT/f'Preview-{label.replace(" ","-")}.png')
        sheet.paste(native.resize((512,512),Image.Resampling.LANCZOS),(j*512,0))
        d.text((j*512+18,518),label,fill=(184,218,231))
        thumbs.append(native.resize((300,300),Image.Resampling.LANCZOS))
    sheet.save(OUT/'Pose-Review.png')
    comparison=Image.new('RGB',(1200,330),(5,9,15));d=ImageDraw.Draw(comparison)
    old=Image.open('/workspace/forge-pass-bloom-samples/Volumetric-Cover.png').convert('RGB')
    comparison.paste(old.resize((300,300),Image.Resampling.LANCZOS),(0,0))
    d.text((18,307),'Previous / half open',fill=(184,218,231))
    for j,(im,(_,label)) in enumerate(zip(thumbs,poses),1):
        comparison.paste(im,(j*300,0));d.text((j*300+18,307),'Refined / '+label.lower(),fill=(184,218,231))
    comparison.save(OUT/'Thumbnail-Comparison.png')
    print('Preview poses and300px comparison saved.',flush=True)


def frame_to_png(i):
    path=OUT/'lossless-frames'/f'{i:04d}.png'
    render(i).save(path,compress_level=2)
    return i


def verification():
    a=np.asarray(render(0),dtype=np.int16)
    b=np.asarray(render(COUNT),dtype=np.int16)
    previous=np.asarray(render(COUNT-1),dtype=np.int16)
    first=np.asarray(render(1),dtype=np.int16)
    max_radius=0
    min_tip_to_halo_clearance=float('inf')
    for i in range(COUNT):
        p=motion_parameters(i)
        for prefix in ['front','rear']:
            paths,tips=sector_geometry(p,prefix)
            max_radius=max(max_radius,max(float(np.linalg.norm(q)) for path,_,_ in paths for q in path))
            if prefix=='front':
                outer_tip=max(float(np.linalg.norm(q)) for q in tips)+4.5
                inner_halo=p['main_halo_radius']-11
                min_tip_to_halo_clearance=min(min_tip_to_halo_clearance,(inner_halo-outer_tip)*SCALE*1000/SIZE)
    return {'sample':'Forge Pass sculpted Volumetric circuit bloom',
            'duration_seconds':SECONDS,'gif_fps':FPS,'expected_gif_frames':COUNT,
            'native_render_size':[NATIVE,NATIVE],'png_size':[2048,2048],'gif_size':[1000,1000],
            'source_geometry_seed':SEED,'composition_scale':SCALE,
            'source_pipeline':'Native procedural RGB geometry -> lossless PNG frames -> single global256-color GIF palette; no video intermediary',
            'loop_endpoint_pixels_identical':bool(np.array_equal(a,b)),
            'seam_mean_rgb_difference':float(np.abs(a-previous).mean()),
            'first_neighbor_mean_rgb_difference':float(np.abs(a-first).mean()),
            'max_branch_center_radius_at1000px':max_radius*SCALE*1000/SIZE,
            'minimum_front_tip_to_inner_halo_clearance_at1000px':min_tip_to_halo_clearance,
            'max_halo_outer_radius_at1000px':(513+7)*SCALE*1000/SIZE,
            'fixed_background_track_radius_at1000px':550*SCALE*1000/SIZE,
            'main_halo_diameter_excursion_at1000px':216*SCALE*1000/SIZE,
            'compact_phase_frame':180,'open_phase_frame':60,
            'png_hero_pose':'Fully open at3.0seconds (frame60)',
            'primary_rail_width_at1000px':15.6*SCALE*1000/SIZE,
            'secondary_rail_width_at1000px':6.4*SCALE*1000/SIZE,
            'thin_rail_width_at1000px':2.9*SCALE*1000/SIZE}


def run():
    start=time.time();OUT.mkdir(parents=True,exist_ok=True)
    (OUT/'lossless-frames').mkdir(exist_ok=True)
    report=verification()
    assert report['loop_endpoint_pixels_identical']
    # At least10px of actual dark separation between a solid terminal and
    # the inward edge of the halo, including both objects' full stroke widths.
    assert report['minimum_front_tip_to_inner_halo_clearance_at1000px']>10
    render_native(60).resize((2048,2048),Image.Resampling.LANCZOS).save(OUT/'Volumetric.png',compress_level=9)
    with multiprocessing.get_context('fork').Pool(processes=3) as pool:
        for i in pool.imap(frame_to_png,range(COUNT),chunksize=1):
            if i%20==0:print(f'Rendered{i}/{COUNT} lossless frames, {time.time()-start:.1f}s',flush=True)
    pattern=str(OUT/'lossless-frames'/'%04d.png')
    common=['ffmpeg','-hide_banner','-loglevel','warning','-y','-threads','2','-framerate',str(FPS),'-i',pattern]
    subprocess.run(common+['-vf','palettegen=max_colors=256:reserve_transparent=0:stats_mode=full',
                    '-frames:v','1','-update','1',str(OUT/'global-palette.png')],check=True)
    subprocess.run(common+['-i',str(OUT/'global-palette.png'),'-filter_complex_threads','2',
                  '-filter_complex','[0:v][1:v]paletteuse=dither=none:diff_mode=rectangle',
                  '-loop','0','-final_delay','5',str(OUT/'Volumetric.gif')],check=True)
    gif=Image.open(OUT/'Volumetric.gif');timings=[]
    for i in range(gif.n_frames):
        gif.seek(i);gif.load();timings.append(gif.info.get('duration'))
    assert gif.n_frames==COUNT and set(timings)=={50} and gif.info.get('loop')==0
    assert gif.size==(1000,1000) and sum(timings)==12000
    size=(OUT/'Volumetric.gif').stat().st_size
    assert size<50_000_000
    report.update({'actual_gif_frames':gif.n_frames,'gif_frame_durations_ms':sorted(set(timings)),
                   'gif_loop':gif.info.get('loop'),'gif_total_duration_ms':sum(timings),
                   'gif_file_bytes':size,'elapsed_seconds':time.time()-start,
                   'files':{name:{'bytes':(OUT/name).stat().st_size,'sha256':hashlib.sha256((OUT/name).read_bytes()).hexdigest()}
                            for name in ['Volumetric.gif','Volumetric.png']}})
    (OUT/'Verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--preview-only',action='store_true')
    args=p.parse_args();initialize()
    if args.preview_only:preview()
    else:run()
