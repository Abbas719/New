#!/usr/bin/env python3
"""Plan, publish, or verify the validated Forge Pass downloads.

Default mode is read-only plan. Explicit --mode publish copies only the named
delivery files, commits at most 400 MB per batch, pushes the authorized branch,
then downloads and checks every public file. Existing different files are never
overwritten. --mode verify only downloads; successful checks are cached locally.
This helper never mints, changes wallet state, force-pushes, or edits artwork.
"""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
from urllib.parse import quote
import zipfile

BRANCH = "forge-pass-sample-download"
BASE_URL = f"https://github.com/aygaladima/New/raw/refs/heads/{BRANCH}"
EXPECTED_COUNTS = {"Preview": 99, "Motion": 66, "Volumetric": 33}
FILE_LIMIT = 95_000_000
DEFAULT_BATCH_LIMIT = 400_000_000
SAFE_NAME = re.compile(r"[A-Za-z0-9_.-]+\Z")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def timestamp():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256(source):
    if isinstance(source, Path):
        with source.open("rb") as stream:
            return sha256(stream)
    digest = hashlib.sha256()
    for chunk in iter(lambda: source.read(1024 * 1024), b""):
        digest.update(chunk)
    return digest.hexdigest()


def save_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)


def git(repo, *arguments, allow_failure=False):
    env = dict(os.environ, GIT_TERMINAL_PROMPT="0")
    pack_options = ["-c", "pack.window=0", "-c", "pack.threads=2"] if arguments and arguments[0] == "push" else []
    result = subprocess.run(["git", *pack_options, *arguments], cwd=repo, env=env,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode and not allow_failure:
        # Do not include Git stderr/config in reports: credential helpers may put
        # sensitive text in their errors. The command purpose is enough to retry.
        raise RuntimeError(f"Git {arguments[0]} failed (exit {result.returncode}); "
                           "inspect authentication/network access locally. No force-push attempted.")
    return result


def git_text(repo, *arguments):
    return git(repo, *arguments).stdout.decode("utf-8").strip()


def remote_head(repo):
    response = git_text(repo, "ls-remote", "origin", f"refs/heads/{BRANCH}")
    fields = response.split()
    require(len(fields) == 2 and re.fullmatch(r"[0-9a-f]{40,64}", fields[0])
            and fields[1] == f"refs/heads/{BRANCH}", "Authorized remote branch is missing or ambiguous")
    return fields[0]


def check_repo(repo):
    require(git_text(repo, "branch", "--show-current") == BRANCH,
            f"Repository must already be on authorized branch {BRANCH}")
    origin = git_text(repo, "config", "--get", "remote.origin.url")
    require(origin in ("https://github.com/Abbas719/New.git", "https://github.com/Abbas719/New",
                       "git@github.com:Abbas719/New.git"), "Unexpected repository remote; refusing delivery")
    require(not git_text(repo, "diff", "--name-only"), "Tracked working-tree edits exist; finish/review them first")
    require(not git_text(repo, "diff", "--cached", "--name-only"), "Staged changes exist; finish/review them first")
    return git_text(repo, "rev-parse", "HEAD"), remote_head(repo)


def check_zip(path, item):
    with zipfile.ZipFile(path) as archive:
        require(archive.testzip() is None, f"ZIP CRC failure: {path.name}")
        if "artworks" in item:
            expected = {entry["artifact"]: entry for entry in item["artworks"]}
            require(len(archive.infolist()) == len(expected) and set(archive.namelist()) == set(expected),
                    f"ZIP artwork coverage mismatch: {path.name}")
            for info in archive.infolist():
                require(info.file_size == expected[info.filename]["bytes"],
                        f"ZIP member size mismatch in {path.name}")
                with archive.open(info) as stream:
                    require(sha256(stream) == expected[info.filename]["sha256"],
                            f"ZIP member SHA256 mismatch in {path.name}")


def load_delivery_files(root):
    packages = root / "packages"
    manifest_path = packages / "Package_Manifest.json"
    manifest = json.loads(manifest_path.read_text())
    require(manifest.get("edition_size") == 198 and manifest.get("artwork_count") == 198 and manifest.get("media_count") == 297
            and manifest.get("tier_counts") == EXPECTED_COUNTS
            and manifest.get("validation_complete") is True
            and manifest.get("coverage_exactly_once") is True, "Package manifest is incomplete")
    archives = manifest["archives"]
    artworks = [entry for archive in archives for entry in archive["artworks"]]
    require(len(artworks) == 297 and {entry["id"] for entry in artworks} == set(range(1, 199)),
            "Packaged IDs must cover 1–198 exactly once")
    require(Counter(entry["tier"] for entry in artworks) == Counter({"Preview":99,"Motion":132,"Volumetric":66}), "Incorrect packaged media tier counts")
    require(len({entry["artifact"] for entry in artworks}) == 297
            and len({entry["sha256"] for entry in artworks}) == 297, "Duplicate artwork paths or hashes")
    files = [dict(archive, kind="artwork_archive") for archive in archives]
    if manifest.get("source_backup"):
        files.append(dict(manifest["source_backup"], kind="source_archive"))
    # Publish the index and manifest last, after all archive batches have landed.
    for filename in ("ForgePass_198_Overview.jpg", "ForgePass_198_Download_All.py", "Package_Manifest.json", "ForgePass_198_Downloads.md"):
        path = packages / filename
        files.append({"filename": filename, "kind": "index", "bytes": path.stat().st_size,
                      "sha256": sha256(path), "url": f"{BASE_URL}/{quote(filename)}"})
    require(len({item["filename"] for item in files}) == len(files), "Duplicate delivery filenames")
    for item in files:
        name = item["filename"]
        require(SAFE_NAME.fullmatch(name), "Unsafe delivery filename")
        require(item.get("url") == f"{BASE_URL}/{quote(name)}", f"Unexpected download URL for {name}")
        path = packages / name
        require(path.is_file() and not path.is_symlink(), f"Missing or symlinked delivery file: {name}")
        require(0 < path.stat().st_size == item["bytes"] < FILE_LIMIT, f"Missing, changed, or oversized file: {name}")
        require(sha256(path) == item["sha256"], f"Local package SHA256 mismatch: {name}")
    return manifest, files


def batch_files(files, byte_limit):
    batches, current, size = [], [], 0
    for item in files:
        if current and (size + item["bytes"] > byte_limit
                        or (item["kind"] == "index" and current[-1]["kind"] != "index")):
            batches.append(current)
            current, size = [], 0
        current.append(item)
        size += item["bytes"]
    if current:
        batches.append(current)
    return batches


def blob_hash(repo, revision, filename):
    result = git(repo, "show", f"{revision}:{filename}", allow_failure=True)
    if result.returncode:
        return None
    return hashlib.sha256(result.stdout).hexdigest()


def pending_commits(repo, remote, local, by_name, byte_limit):
    known = git(repo, "cat-file", "-e", f"{remote}^{{commit}}", allow_failure=True)
    require(known.returncode == 0, "Remote branch changed to an unknown commit; fetch and review before retrying")
    ancestor = git(repo, "merge-base", "--is-ancestor", remote, local, allow_failure=True)
    require(ancestor.returncode == 0, "Remote branch diverged or is ahead; review before retrying")
    commits = git_text(repo, "rev-list", "--reverse", f"{remote}..{local}").splitlines()
    for commit in commits:
        parents = git_text(repo, "rev-list", "--parents", "-n", "1", commit).split()
        require(len(parents) == 2, "Unpushed merge/root commit found; review before delivery")
        statuses = git_text(repo, "diff-tree", "--no-commit-id", "--name-status", "-r", commit).splitlines()
        changed = []
        for line in statuses:
            fields = line.split("\t")
            require(len(fields) == 2 and fields[0] == "A" and fields[1] in by_name,
                    "Unpushed commit contains non-delivery edits; review before delivery")
            item = by_name[fields[1]]
            require(blob_hash(repo, commit, item["filename"]) == item["sha256"],
                    f"Unpushed delivery blob differs from current package: {item['filename']}")
            changed.append(item)
        require(changed and sum(item["bytes"] for item in changed) <= byte_limit,
                "Unpushed delivery commit is empty or exceeds the batch byte limit")
    return commits


def inspect_delivery(repo, files, byte_limit):
    local, remote = check_repo(repo)
    by_name = {item["filename"]: item for item in files}
    pending = pending_commits(repo, remote, local, by_name, byte_limit)
    remaining = []
    for item in files:
        name = item["filename"]
        existing = repo / name
        head_hash = blob_hash(repo, "HEAD", name)
        if head_hash is not None:
            require(head_hash == item["sha256"], f"Existing tracked file differs; preserving it: {name}")
        elif existing.exists():
            require(existing.is_file() and not existing.is_symlink() and sha256(existing) == item["sha256"],
                    f"Existing untracked file differs; preserving it: {name}")
            remaining.append(item)
        else:
            remaining.append(item)
    return local, remote, pending, batch_files(remaining, byte_limit)


def push_commit(repo, commit, expected_remote):
    require(remote_head(repo) == expected_remote, "Remote changed during delivery; stopping without force-push")
    git(repo, "push", "origin", f"{commit}:refs/heads/{BRANCH}")
    require(remote_head(repo) == commit, "Remote HEAD did not match the pushed commit")
    print(f"PUSHED {commit[:12]}", flush=True)
    return commit


def publish(root, repo, files, byte_limit, state_dir):
    local, remote, pending, batches = inspect_delivery(repo, files, byte_limit)
    save_json(state_dir / "Publish_Plan.json", {
        "created_at": timestamp(), "branch": BRANCH, "starting_local_commit": local,
        "starting_remote_commit": remote, "pending_delivery_commits": pending,
        "batch_limit": byte_limit, "batches": [[item["filename"] for item in batch] for batch in batches],
    })
    for commit in pending:
        remote = push_commit(repo, commit, remote)
    for index, batch in enumerate(batches, 1):
        require(not git_text(repo, "diff", "--name-only")
                and not git_text(repo, "diff", "--cached", "--name-only"), "Repository changed during delivery")
        for item in batch:
            source, destination = root / "packages" / item["filename"], repo / item["filename"]
            require(sha256(source) == item["sha256"], f"Package changed before staging: {item['filename']}")
            if not destination.exists():
                # Copy atomically within the repository filesystem. An interrupted
                # copy cannot leave a truncated file under the delivery filename.
                with tempfile.NamedTemporaryFile(prefix=".forge-delivery-", dir=repo, delete=False) as handle:
                    temporary = Path(handle.name)
                try:
                    shutil.copyfile(source, temporary)
                    require(sha256(temporary) == item["sha256"], "Copy checksum mismatch")
                    temporary.chmod(0o644)
                    require(not destination.exists(), f"Delivery filename appeared during copy: {destination.name}")
                    temporary.replace(destination)
                finally:
                    temporary.unlink(missing_ok=True)
            require(sha256(destination) == item["sha256"], f"Repository copy mismatch: {destination.name}")
        filenames = [item["filename"] for item in batch]
        git(repo, "add", "--", *filenames)
        staged = set(git_text(repo, "diff", "--cached", "--name-only").splitlines())
        require(staged == set(filenames), "Unexpected staged files; stopping before commit")
        git(repo, "commit", "-m", f"Add Forge Pass 198 collection delivery batch {index}/{len(batches)}")
        commit = git_text(repo, "rev-parse", "HEAD")
        remote = push_commit(repo, commit, remote)
        save_json(state_dir / "Publish_Progress.json", {"checked_at": timestamp(), "remote_commit": remote,
                                                        "last_batch": filenames})
    require(git_text(repo, "rev-parse", "HEAD") == remote_head(repo), "Local and remote HEAD differ after delivery")
    return remote


def download_one(item, remote_commit, staging):
    target = staging / item["filename"]
    command = ["curl", "--fail", "--location", "--silent", "--show-error", "--max-time", "180",
               "--connect-timeout", "30", "--retry", "2", "--retry-delay", "2",
               "--proto", "=https", "--proto-redir", "=https", "--output", str(target),
               "--write-out", "%{http_code}", item["url"]]
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        require(result.returncode == 0 and result.stdout.decode().strip() == "200",
                f"Public download failed for {item['filename']} (curl {result.returncode})")
        require(target.stat().st_size == item["bytes"], f"Downloaded byte count differs: {item['filename']}")
        require(sha256(target) == item["sha256"], f"Downloaded SHA256 differs: {item['filename']}")
        is_zip = item["filename"].endswith(".zip")
        if is_zip:
            check_zip(target, item)
        return {"status": "verified", "filename": item["filename"], "bytes": item["bytes"],
                "sha256": item["sha256"], "url": item["url"], "remote_commit": remote_commit,
                "checked_at": timestamp(), "http_status": 200, "zip_crc_verified": is_zip,
                "artwork_member_hashes_verified": "artworks" in item}
    finally:
        target.unlink(missing_ok=True)


def verify(repo, files, state_dir, jobs, force):
    commit = remote_head(repo)
    cache_path = state_dir / "Remote_Verification.json"
    try:
        old = json.loads(cache_path.read_text())
    except (OSError, ValueError):
        old = {}
    records = old.get("files", {})
    records = {item["filename"]: records[item["filename"]] for item in files
               if not force and records.get(item["filename"], {}).get("status") == "verified"
               and all(records[item["filename"]].get(key) == value for key, value in
                       (("remote_commit", commit), ("sha256", item["sha256"]),
                        ("bytes", item["bytes"]), ("url", item["url"])))}
    pending = [item for item in files if item["filename"] not in records]
    state = {"branch": BRANCH, "remote_commit": commit, "complete": False,
             "expected_files": len(files), "checked_at": timestamp(), "files": records}
    save_json(cache_path, state)
    print(f"VERIFY {len(pending)} downloads, {len(records)} cached, {jobs} concurrent", flush=True)
    errors = []
    state_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="downloads-", dir=state_dir) as temporary:
        with ThreadPoolExecutor(max_workers=jobs) as pool:
            futures = {pool.submit(download_one, item, commit, Path(temporary)): item for item in pending}
            for future in as_completed(futures):
                item = futures[future]
                try:
                    record = future.result()
                    records[item["filename"]] = record
                    print(f"VERIFIED {item['filename']} {item['bytes']:,} bytes", flush=True)
                except Exception as error:
                    errors.append(f"{item['filename']}: {error}")
                    print(f"VERIFY FAILED {item['filename']}: {error}", flush=True)
                state["checked_at"] = timestamp()
                save_json(cache_path, state)
    require(remote_head(repo) == commit, "Remote branch changed during verification; rerun to refresh evidence")
    state.update(complete=not errors and len(records) == len(files), errors=errors,
                 verified_files=len(records), verified_bytes=sum(record["bytes"] for record in records.values()),
                 checked_at=timestamp())
    save_json(cache_path, state)
    require(state["complete"], f"{len(errors)} download verification failures; successful checks are cached")
    return state


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--repo", type=Path, default=Path("/workspace/New"))
    parser.add_argument("--mode", choices=("plan", "publish", "verify"), default="plan")
    parser.add_argument("--batch-bytes", type=int, default=DEFAULT_BATCH_LIMIT)
    parser.add_argument("--jobs", type=int, choices=range(1, 5), default=2, help="Concurrent public downloads, default 2")
    parser.add_argument("--force-verify", action="store_true", help="Download again instead of using matching verified cache entries")
    args = parser.parse_args()
    require(300_000_000 <= args.batch_bytes <= 500_000_000, "Batch byte limit must be between 300 and 500 MB")
    root, repo = args.root.resolve(), args.repo.resolve()
    require(shutil.which("git") and shutil.which("curl"), "git and curl must be installed")
    manifest, files = load_delivery_files(root)
    state_dir = root / "internal" / "delivery"
    if args.mode == "plan":
        local, remote, pending, batches = inspect_delivery(repo, files, args.batch_bytes)
        print(json.dumps({"mode": "plan", "mutations": False, "branch": BRANCH,
                          "local_commit": local, "remote_commit": remote, "pending_delivery_commits": pending,
                          "delivery_files": len(files), "delivery_bytes": sum(item["bytes"] for item in files),
                          "batch_limit": args.batch_bytes,
                          "batches": [{"bytes": sum(item["bytes"] for item in batch),
                                       "files": [item["filename"] for item in batch]} for batch in batches]}, indent=2))
        return 0
    if args.mode == "publish":
        publish(root, repo, files, args.batch_bytes, state_dir)
    else:
        check_repo(repo)
    result = verify(repo, files, state_dir, args.jobs, args.force_verify)
    print(json.dumps({key: result[key] for key in ("complete", "remote_commit", "verified_files", "verified_bytes")}, indent=2))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, RuntimeError, zipfile.BadZipFile) as error:
        print(f"Delivery stopped: {error}", file=sys.stderr)
        sys.exit(1)
