"""Resumable production and full media validation; requires ffmpeg on PATH."""
from pathlib import Path
import os,json,time,hashlib,subprocess,shutil,traceback,concurrent.futures,argparse
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
from renderer import Renderer, np
from PIL import Image, ImageDraw
ROOT=Path(__file__).resolve().parents[1]
def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def dump(path,data):
    path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,indent=2)+'\n');temp.replace(path)
def still(item):
    path=ROOT/'artwork'/item['png'];path.parent.mkdir(parents=True,exist_ok=True)
    report=ROOT/'internal'/'reports'/f"{item['id']:03d}_png.json"
    if report.exists() and path.exists():
        data=json.loads(report.read_text())
        if data['geometry_sha256']==item['geometry_sha256'] and data['sha256']==sha(path):return data
    t=time.time();r=Renderer(item['geometry'],item['tier']);frame=60 if item['tier']=='Volumetric' else 0
    im=r.render(frame,2048);im.save(path,compress_level=6)
    im.thumbnail((320,320),Image.Resampling.LANCZOS)
    thumb=ROOT/'internal'/'thumbnails'/f"{item['id']:03d}.jpg";thumb.parent.mkdir(exist_ok=True,parents=True);im.save(thumb,quality=94)
    with Image.open(path) as check:check.load();assert check.size==(2048,2048) and check.mode=='RGB'
    data={'id':item['id'],'geometry_sha256':item['geometry_sha256'],'file':item['png'],'bytes':path.stat().st_size,'sha256':sha(path),'seconds':round(time.time()-t,2)};dump(report,data);return data

def run(cmd):subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
def animate(item):
    path=ROOT/'artwork'/item['gif'];report=ROOT/'internal'/'reports'/f"{item['id']:03d}_gif.json"
    if report.exists() and path.exists():
        data=json.loads(report.read_text())
        if data['geometry_sha256']==item['geometry_sha256'] and data['sha256']==sha(path):return data
    started=time.time();work=ROOT/'internal'/'frames'/f"{item['id']:03d}";work.mkdir(parents=True,exist_ok=True)
    r=Renderer(item['geometry'],item['tier']);n=r.frames
    native0=np.array(r.render(0));native_end=np.array(r.render(n));assert np.array_equal(native0,native_end),'Native loop endpoint mismatch'
    # Render PNG frames once; all palette retries reuse these exact frames.
    for f in range(n):
        dest=work/f'{f:04d}.png'
        if not dest.exists():r.render(f).save(dest,compress_level=1)
    rendered=time.time()
    base=['ffmpeg','-hide_banner','-loglevel','error','-y','-threads','1','-filter_threads','1']
    output=path.with_suffix('.working.gif');path.parent.mkdir(parents=True,exist_ok=True)
    for colors in (256,192,128):
        palette=work/'palette.png'
        run(base+['-framerate','20','-i',str(work/'%04d.png'),'-vf',f'palettegen=max_colors={colors}:reserve_transparent=0:stats_mode=full','-frames:v','1','-update','1',str(palette)])
        run(base+['-framerate','20','-i',str(work/'%04d.png'),'-i',str(palette),'-filter_complex_threads','1','-filter_complex','[0:v][1:v]paletteuse=dither=none:diff_mode=rectangle','-loop','0','-final_delay','5',str(output)])
        if output.stat().st_size<50_000_000:break
    assert output.stat().st_size<50_000_000,'GIF exceeds 50 MB'
    encoded=time.time();duration=0;hub=None;poses={};indices={0,1,n//4,n//2,3*n//4,n-1}
    with Image.open(output) as im:
        assert im.size==(1000,1000) and im.n_frames==n and im.info.get('loop')==0
        for f in range(n):
            im.seek(f);im.load();assert im.info['duration']==50
            duration+=im.info['duration'];rgb=im.convert('RGB')
            center=np.array(rgb.crop((472,472,528,528)))
            if hub is None:hub=center
            else:assert np.array_equal(hub,center),'Hub changes in encoded GIF'
            if f in indices:poses[f]=np.array(rgb,dtype=np.int16)
    delta=lambda a,b:float(np.abs(poses[a]-poses[b]).mean())
    seam=delta(n-1,0);step=delta(0,1);motion=delta(0,n//4)
    assert seam<max(.05,step*1.85),(seam,step)
    assert motion>.6,motion
    assert duration==n*50
    output.replace(path)
    data={'id':item['id'],'geometry_sha256':item['geometry_sha256'],'file':item['gif'],'bytes':path.stat().st_size,'sha256':sha(path),'frames':n,'duration_ms':duration,'fps':20,'palette_colors':colors,'loop':0,'native_endpoint_identical':True,'fixed_hub_every_frame':True,'seam_mean_delta':seam,'ordinary_step_mean_delta':step,'quarter_cycle_mean_delta':motion,'render_seconds':round(rendered-started,2),'encode_seconds':round(encoded-rendered,2),'total_seconds':round(time.time()-started,2)}
    dump(report,data);shutil.rmtree(work)
    return data

def sheets(items):
    groups=list(dict.fromkeys(i['structure'] for i in items))
    for group in groups:
        members=[i for i in items if i['structure']==group]
        out=Image.new('RGB',(6*320,3*350),(8,14,20));d=ImageDraw.Draw(out)
        for idx,item in enumerate(members):
            x=(idx%6)*320;y=(idx//6)*350
            with Image.open(ROOT/'internal'/'thumbnails'/f"{item['id']:03d}.jpg") as im:out.paste(im,(x,y))
            d.text((x+9,y+325),f"{item['id']:03d}  {item['tier']}  {group}",fill=(180,232,245))
        out.save(ROOT/'internal'/f'Contact_{group}.jpg',quality=93)
    overview=Image.new('RGB',(6*320,6*350),(8,14,20));d=ImageDraw.Draw(overview)
    reps=[next(i for i in items if i['structure']==g and i['tier']==t) for g in groups for t in ('Preview','Motion','Volumetric')]
    for idx,item in enumerate(reps):
        x=idx%6*320;y=idx//6*350
        with Image.open(ROOT/'internal'/'thumbnails'/f"{item['id']:03d}.jpg") as im:overview.paste(im,(x,y))
        d.text((x+8,y+325),f"{item['id']:03d} {item['tier']} {item['structure']}",fill=(180,232,245))
    overview.save(ROOT/'internal'/'Collection_Overview.jpg',quality=94)

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['stills','animations','sheets']);p.add_argument('--workers',type=int,default=3);p.add_argument('--ids',default='');args=p.parse_args()
    items=json.loads((ROOT/'Collection.json').read_text())['items']
    if args.mode=='sheets':sheets(items);return
    if args.ids:
        ids=set(map(int,args.ids.split(',')));items=[i for i in items if i['id'] in ids]
    if args.mode=='animations':items=[i for i in items if 'gif' in i]
    errors=[]
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(still if args.mode=='stills' else animate,i):i for i in items}
        for f in concurrent.futures.as_completed(futures):
            item=futures[f]
            try:
                data=f.result();print(json.dumps({'done':item['id'],'mode':args.mode,'bytes':data['bytes'],'seconds':data.get('total_seconds',data.get('seconds'))}),flush=True)
            except Exception as ex:
                detail=traceback.format_exc();errors.append({'id':item['id'],'error':detail});print(detail,flush=True)
    if errors:dump(ROOT/'internal'/f'{args.mode}_errors.json',errors);raise RuntimeError(f'{len(errors)} artworks failed')
    if args.mode=='stills' and not args.ids:sheets(items)
if __name__=='__main__':main()
