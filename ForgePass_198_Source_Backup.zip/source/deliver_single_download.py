"""Create a collection-only repository snapshot, then verify its single ZIP download."""
from pathlib import Path
import os,json,subprocess,zipfile,hashlib
from deliver_collection import git,git_text,load_delivery_files,sha256,save_json
ROOT=Path(__file__).resolve().parents[1];REPO=Path('/workspace/New')
BRANCH='forge-pass-198-collection'
def main():
 state=json.loads((ROOT/'internal'/'delivery'/'Remote_Verification.json').read_text())
 assert state['complete'],'Per-file public download verification must finish first'
 manifest,files=load_delivery_files(ROOT)
 head=git_text(REPO,'rev-parse','HEAD')
 assert head==state['remote_commit']
 names=[i['filename'] for i in files]
 entries=git(REPO,'ls-tree','-z',head,'--',*names).stdout
 assert len(entries.split(b'\x00'))-1==len(names)
 total=sum(f['bytes'] for f in files)
 readme=f'''# Forge Pass — full 198-artwork collection

99 Preview, 66 Motion, 33 Volumetric. 198 PNG masters and 99 animated GIFs.

This collection download is approximately {total/1e9:.2f} GB. It contains independent
art ZIPs so you can also download smaller batches when needed.

1. Extract this outer ZIP.
2. Extract every Preview, Motion, and Volumetric ZIP into one folder.
3. The combined Preview / Motion / Volumetric folders contain all 297 art files.

PNG masters: 2048×2048. GIFs: 1000×1000, 20 fps, infinite looping, below 50 MB each.
Motion lasts 24 seconds; Volumetric lasts 12 seconds.

The optional Source Backup ZIP contains code and documentation, not additional editions.
The optional Download All Python helper is an alternative to manual ZIP downloads.

[Individual download links and details](ForgePass_198_Downloads.md)

[Collection overview](ForgePass_198_Overview.jpg)

Artwork exports only; no NFTs have been minted or published to OpenSea.
'''
 env=dict(os.environ,GIT_TERMINAL_PROMPT='0')
 blob=subprocess.run(['git','hash-object','-w','--stdin'],cwd=REPO,input=readme.encode(),capture_output=True,check=True,env=env).stdout.strip()
 entries+=b'100644 blob '+blob+b'\tREADME.md\x00'
 tree=subprocess.run(['git','mktree','-z'],cwd=REPO,input=entries,capture_output=True,check=True,env=env).stdout.decode().strip()
 remote=git_text(REPO,'ls-remote','origin','refs/heads/'+BRANCH).split()
 if remote:
  commit=remote[0]
  assert git_text(REPO,'rev-parse',commit+'^{tree}')==tree,'Existing collection branch differs; preserve and review'
 else:
  commit=subprocess.run(['git','commit-tree',tree,'-p',head,'-m','Publish complete Forge Pass 198 artwork download snapshot'],cwd=REPO,capture_output=True,check=True,env=env).stdout.decode().strip()
  git(REPO,'push','origin',commit+':refs/heads/'+BRANCH)
 assert git_text(REPO,'ls-remote','origin','refs/heads/'+BRANCH).split()[0]==commit
 print('Published collection-only snapshot',commit,flush=True)
 url=f'https://github.com/aygaladima/New/archive/refs/heads/{BRANCH}.zip'
 target=ROOT/'internal'/'ForgePass_198_Complete_Download.zip'
 print('Downloading and verifying the complete archive',flush=True)
 result=subprocess.run(['curl','--fail','--location','--silent','--show-error','--max-time','600','--connect-timeout','30','--retry','1','--speed-limit','1024','--speed-time','60','--proto','=https','--proto-redir','=https','--output',str(target),'--write-out','%{http_code}',url],capture_output=True)
 assert result.returncode==0 and result.stdout.decode().strip()=='200','Complete ZIP download failed'
 expected={i['filename']:i for i in files}
 expected['README.md']={'bytes':len(readme.encode()),'sha256':hashlib.sha256(readme.encode()).hexdigest()}
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None,'Complete download ZIP CRC mismatch'
  members=[i for i in z.infolist() if not i.is_dir()]
  prefixes={i.filename.split('/',1)[0] for i in members};assert len(prefixes)==1
  actual={i.filename.split('/',1)[1]:i for i in members};assert set(actual)==set(expected)
  for name,info in actual.items():
   assert info.file_size==expected[name]['bytes']
   with z.open(info) as f:assert sha256(f)==expected[name]['sha256'],name
 report={'complete':True,'url':url,'branch':BRANCH,'commit':commit,'bytes':target.stat().st_size,'sha256':sha256(target),'zip_crc_verified':True,'all_member_sha256_matches':True,'artwork_archives':len(manifest['archives']),'png_count':198,'gif_count':99}
 save_json(ROOT/'internal'/'delivery'/'Single_Download_Verification.json',report)
 print(json.dumps(report,indent=2),flush=True)
if __name__=='__main__':main()
