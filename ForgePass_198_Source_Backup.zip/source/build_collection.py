"""Deterministic, connected five-arm branching collection. No palette-only variants."""
from pathlib import Path
import json, math, random, hashlib
ROOT=Path(__file__).resolve().parents[1]
PROFILES=[
 ('Classic',[181,286,396],1.0,1.0,0.78,0.0),
 ('Spire',[160,273,389],0.65,1.10,0.65,0.0),
 ('Canopy',[165,266,375],1.48,0.88,0.68,0.0),
 ('Terrace',[145,225,310,392],1.05,0.83,0.40,0.0),
 ('Solstice',[205,355],1.35,1.12,0.85,0.0),
 ('Crown',[245,318,390],1.30,0.88,0.60,0.0),
 ('Fork',[170,280,388],1.15,1.0,1.0,0.0),
 ('Ascent',[155,263,379],1.05,1.05,0.65,0.65),
 ('Current',[175,281,390],1.0,1.0,0.65,0.40),
 ('Lattice',[160,258,375],1.35,0.96,0.90,0.0),
 ('Beacon',[190,300,397],0.85,1.0,0.58,0.0),
]
def fingerprint(x):return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def geometry(seed,profile,variant):
    rng=random.Random(seed)
    name,levels,spread,reach,twigs,sweep=profile
    phase=-92+rng.uniform(-8,8)
    angles=[phase+72*i for i in range(5)]
    paths=[];tips=[]
    for arm,deg in enumerate(angles):
        rad=math.radians(deg);co,si=math.cos(rad),math.sin(rad)
        def world(p):return [round(p[0]*co-p[1]*si,6),round(p[0]*si+p[1]*co,6)]
        def add(points,width,terminal=True):
            assert all(math.dist(a,b)>1 for a,b in zip(points,points[1:]))
            paths.append(([world(p) for p in points],width,arm))
            if terminal:tips.append((world(points[-1]),arm))
        bend=rng.uniform(-14,14)
        local_levels=[x+rng.uniform(-12,12) for x in levels]
        trunk=[(58,0)]+[(x,bend*(x/440)+rng.uniform(-9,9)+sweep*24*math.sin((j+1)*1.1+arm*.6)) for j,x in enumerate(local_levels)]
        trunk.append((rng.uniform(437,453),bend+rng.uniform(-15,15)))
        add(trunk,3.0)
        for j,parent in enumerate(trunk[1:-1]):
            for side in [-1,1]:
                # Structured omissions change connectivity, rather than just the pose.
                if name=='Solstice' and j==0 and side==(-1 if arm%2 else 1) and rng.random()<.22:continue
                rem=455-parent[0]
                length=min((110 if j<2 else 70)*reach*rng.uniform(.82,1.12),rem*.78)
                theta=side*(.50-.07*min(j,2))*spread+rng.uniform(-.065,.065)
                if name=='Ascent':theta*=.65 if side==1 else 1.25
                if name=='Current':theta+=.14
                q1=(parent[0]+length*math.cos(theta),parent[1]+length*math.sin(theta))
                outer=j==len(levels)-1
                if outer:
                    add([parent,q1],1.7)
                else:
                    ext=min((83-j*13)*reach*rng.uniform(.82,1.10),(456-q1[0])*.86)
                    theta2=theta+side*(.25 if name!='Lattice' else .42)
                    q2=(q1[0]+ext*math.cos(theta2),q1[1]+ext*math.sin(theta2))
                    # Reduce the whole offshoot uniformly to stay inside its sector.
                    delta=1.0
                    while math.hypot(*q2)>460 or abs(math.atan2(q2[1],q2[0]))>math.radians(26):
                        delta*=.97
                        q2=(parent[0]+(q2[0]-parent[0])*.97,parent[1]+(q2[1]-parent[1])*.97)
                        q1=(parent[0]+(q1[0]-parent[0])*.97,parent[1]+(q1[1]-parent[1])*.97)
                    add([parent,q1,q2],1.9)
                    if rng.random()<twigs:
                        length2=min(rng.uniform(42,65),(456-q1[0])*.88)
                        t=theta-side*rng.uniform(.40,.69)
                        q3=(q1[0]+length2*math.cos(t),q1[1]+length2*math.sin(t))
                        add([q1,q3],1.35)
        # Fine terminal fork on selected crowns creates another genuine topology.
        if name in ('Crown','Beacon','Fork') and rng.random()<.6:
            parent=trunk[-2]
            end=(min(450,parent[0]+rng.uniform(30,52)),parent[1]+rng.choice([-1,1])*rng.uniform(20,33))
            add([parent,end],1.35)
    g={'angles':angles,'paths':paths,'tips':tips}
    assert all(math.hypot(*p)<470 for ps,_,_ in paths for p in ps)
    return g

def main():
    items=[]
    for tier,start,count in [('Preview',1,9),('Motion',100,6),('Volumetric',166,3)]:
        for pi,profile in enumerate(PROFILES):
            for v in range(count):
                ident=start+pi*count+v;seed=850199+ident*7919
                g=geometry(seed,profile,v)
                item={'id':ident,'name':f'Forge Pass #{ident:03d}','tier':tier,'structure':profile[0],'seed':seed,'geometry_sha256':fingerprint(g),'geometry':g,'png':f'{tier}/ForgePass_{ident:03d}_{tier}.png'}
                if tier!='Preview':item['gif']=f'{tier}/ForgePass_{ident:03d}_{tier}.gif'
                items.append(item)
    items.sort(key=lambda x:x['id'])
    assert len(set(i['geometry_sha256'] for i in items))==198
    manifest={'collection':'Forge Pass','edition_size':198,'counts':{'Preview':99,'Motion':66,'Volumetric':33},'png_size':[2048,2048],'gif_size':[1000,1000],'fps':20,'motion_seconds':24,'volumetric_seconds':12,'style':'Crisp five-arm cyan branching; fixed faceted hub; dark navy background','items':items}
    (ROOT/'Collection.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('Created',len(items),'distinct connected branch graphs; paths range',min(len(i['geometry']['paths']) for i in items),max(len(i['geometry']['paths']) for i in items))
if __name__=='__main__':main()
