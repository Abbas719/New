"""Antialiased vector rasterization of the approved crisp drawing primitives."""
from pathlib import Path
import sys, math, json, hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
import numpy as np
import skia
from PIL import Image, ImageDraw, ImageChops, ImageFilter
import approved_style as a

_cache={}

class Draw:
    def __init__(self,canvas):self.c=canvas
    def paint(self,color,stroke=None):
        p=skia.Paint(AntiAlias=True,Color=skia.ColorSetRGB(*map(int,color)))
        if stroke is not None:
            p.setStyle(skia.Paint.kStroke_Style);p.setStrokeWidth(stroke)
            p.setStrokeJoin(skia.Paint.kRound_Join);p.setStrokeCap(skia.Paint.kButt_Cap)
        return p
    def path(self,pts,close=False):
        p=skia.Path();p.moveTo(*map(float,pts[0]))
        for q in pts[1:]:p.lineTo(*map(float,q))
        if close:p.close()
        return p
    def line(self,pts,fill,width,joint=None):self.c.drawPath(self.path(pts),self.paint(fill,width))
    def polygon(self,pts,fill):self.c.drawPath(self.path(pts,True),self.paint(fill))
    def ellipse(self,box,fill=None,outline=None,width=1):
        rect=skia.Rect.MakeLTRB(*map(float,box))
        if fill is not None:self.c.drawOval(rect,self.paint(fill))
        if outline is not None:
            rect.inset(width/2,width/2);self.c.drawOval(rect,self.paint(outline,width))
    def arc(self,box,start,end,fill,width):
        rect=skia.Rect.MakeLTRB(*map(float,box));rect.inset(width/2,width/2)
        self.c.drawArc(rect,float(start),float(end-start),False,self.paint(fill,width))

def resources(size):
    if 'native' not in _cache:
        a.initialize();_cache['native']=(a.BG,a.HUB,a.HUB_MASK)
    if size not in _cache:
        bg,hub,mask=_cache['native']
        bg=bg.resize((size,size),Image.Resampling.LANCZOS)
        hub=hub.resize((size,size),Image.Resampling.LANCZOS)
        mask=mask.resize((size,size),Image.Resampling.LANCZOS)
        _cache[size]=(skia.Image.fromarray(np.array(bg.convert('RGBA')),colorType=skia.ColorType.kRGBA_8888_ColorType),hub,mask)
    return _cache[size]

def halo(d,r,rotation=0,layer='front'):
    if layer=='rear':a.segmented_halo(d,r,'rear');return
    def arc(radius,width,color,start,offset=(0,0)):
        x,y=a.coord((0,0),offset);rr=radius*a.SS*a.SCALE
        d.arc((x-rr,y-rr,x+rr,y+rr),start,start+28,color,max(1,round(width*a.SS*a.SCALE)))
    for i in range(10):
        start=3+i*36+rotation;light=(1+math.cos(math.radians(start+14-225)))*.5
        arc(r+1,12.5,(1,24,45),start,(3,5.5));arc(r,11,(2,68,101),start)
        arc(r-1.8,7,(5,int(143+31*light),int(189+22*light)),start)
        arc(r-2,1.4,(int(70+60*light),int(209+26*light),int(233+14*light)),start)
        arc(r-8,1,(4,95,143),start)

class Renderer:
    def __init__(self,geometry,tier):
        self.g=geometry;self.tier=tier;self.frames={'Preview':1,'Motion':480,'Volumetric':240}[tier]
        self.paths=[(np.array(p,dtype=float),w,arm) for p,w,arm in geometry['paths']]
        self.tips=[(np.array(p,dtype=float),arm) for p,arm in geometry['tips']]
    def transformed(self,frame,layer='front'):
        if self.tier=='Volumetric':p=a.motion_parameters(frame)
        else:p=a.motion_parameters(60)
        rotation=360*(frame%480)/480 if self.tier=='Motion' else 0
        scale=p[layer+'_scale'];hinge=p[layer+'_hinge'];radial=p[layer+'_radial_offset']
        matrices=[];offsets=[]
        for arm,axis in enumerate(self.g['angles']):
            turn=(-1 if arm%2==0 else 1)*hinge+rotation
            rad=math.radians(turn);co,si=math.cos(rad),math.sin(rad)
            matrices.append(np.array([[co,-si],[si,co]])*scale)
            offsets.append(a.polar(radial,math.radians(axis+turn)))
        result=[];feeders=[]
        for path,w,arm in self.paths:
            q=path@matrices[arm].T+offsets[arm];result.append((q,w,arm))
            if w>2.5 and np.linalg.norm(path[0])<82:
                r=np.linalg.norm(q[0])
                if r>63:feeders.append((np.array([q[0]/r*63,q[0]]),3.,arm))
        tips=[tip@matrices[arm].T+offsets[arm] for tip,arm in self.tips]
        return result+feeders,tips,p,rotation
    def render(self,frame=0,size=1000):
        bg,hub,mask=resources(size)
        surface=skia.Surface(size,size);c=surface.getCanvas();c.drawImage(bg,0,0)
        c.save();c.scale(size/a.NATIVE,size/a.NATIVE);d=Draw(c)
        if self.tier=='Volumetric':
            paths,tips,p,_=self.transformed(frame,'rear')
            for path,w,arm in paths:a.rail(d,path,w,arm,'rear')
            for pt in tips:a.circle(d,pt,2.8,(22,139,205))
            halo(d,p['inner_halo_radius'],layer='rear')
        paths,tips,p,rotation=self.transformed(frame)
        for path,w,arm in sorted(paths,key=lambda r:-r[1]):a.rail(d,path,w,arm)
        for pt in tips:
            a.circle(d,pt,4.5,(2,47,69),offset=(1.8,2.7))
            for radius,col in [(4,(3,110,148)),(2.4,(82,220,237)),(1,(196,248,252))]:a.circle(d,pt,radius,col)
        halo(d,p['main_halo_radius'],-rotation)
        c.restore()
        array=surface.makeImageSnapshot().toarray(colorType=skia.ColorType.kRGBA_8888_ColorType)
        im=Image.fromarray(array[:,:,:3].copy());im.paste(hub,(0,0),mask)
        emission=im.point([max(0,round((v-125)*.20)) for v in range(256)]*3)
        return ImageChops.add(im,emission.filter(ImageFilter.GaussianBlur(2.1*a.SCALE*size/a.SIZE)))

if __name__=='__main__':
    import time
    src=json.loads((Path(__file__).parent/'reference_geometry.json').read_text())
    # Reference JSON paths use named entries; source tips are regenerated exactly.
    a.initialize()
    g={'angles':src['angles'],'paths':[(p['points'],p['width'],p['arm']) for p in src['paths']],
       'tips':[(p.tolist(),arm) for p,arm in zip(a.FRONT_TIPS,a.TIP_ARMS)]}
    r=Renderer(g,'Volumetric');r.render(60).save(Path(__file__).parents[1]/'internal/Reference_Vector.png')
    t=time.time()
    for i in range(20):r.render(i)
    print('seconds per frame',(time.time()-t)/20)
