"""Final inventory, geometry, and file integrity checks after per-frame validation."""
from pathlib import Path
import json,hashlib,collections,math
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def validate():
 manifest=json.loads((ROOT/'Collection.json').read_text());items=manifest['items']
 assert len(items)==198 and [i['id'] for i in items]==list(range(1,199))
 assert collections.Counter(i['tier'] for i in items)=={'Preview':99,'Motion':66,'Volumetric':33}
 assert len({i['geometry_sha256'] for i in items})==198
 files=[];geometry_checks=[]
 for item in items:
  g=item['geometry'];assert len(g['angles'])==5
  # Every path is connected to a hub-rooted branch graph, including twigs.
  for arm in range(5):
   arm_paths=[ps for ps,w,idx in g['paths'] if idx==arm]
   roots=[ps for ps in arm_paths if math.hypot(*ps[0])<60];assert len(roots)==1
   reached={tuple(p) for p in roots[0]};remaining=[p for p in arm_paths if p!=roots[0]]
   while remaining:
    attached=[p for p in remaining if tuple(p[0]) in reached];assert attached,(item['id'],'disconnected branch')
    for p in attached:reached.update(map(tuple,p));remaining.remove(p)
   assert all(tuple(tip) in reached for tip,a in g['tips'] if a==arm)
   assert all(math.dist(a,b)>1 for p in arm_paths for a,b in zip(p,p[1:]))
  for kind in ('png','gif'):
   if kind not in item:continue
   path=ROOT/'artwork'/item[kind];rep=json.loads((ROOT/'internal'/'reports'/f"{item['id']:03d}_{kind}.json").read_text())
   assert path.exists() and path.stat().st_size==rep['bytes'] and sha(path)==rep['sha256']
   assert rep['geometry_sha256']==item['geometry_sha256']
   if kind=='png':
    with Image.open(path) as im:im.load();assert im.size==(2048,2048) and im.mode=='RGB'
   else:
    assert rep['bytes']<50_000_000 and rep['native_endpoint_identical'] and rep['fixed_hub_every_frame']
    assert rep['frames']==(480 if item['tier']=='Motion' else 240) and rep['duration_ms']==rep['frames']*50 and rep['loop']==0
   files.append({**rep,'artifact':item[kind],'tier':item['tier'],'format':kind,'structure':item['structure']})
  geometry_checks.append({'id':item['id'],'connected_arms':5,'paths':len(g['paths']),'terminal_lights':len(g['tips'])})
 expected={f['artifact'] for f in files};actual={str(p.relative_to(ROOT/'artwork')) for p in (ROOT/'artwork').rglob('*') if p.is_file()}
 assert expected==actual and len(files)==297 and len({f['sha256'] for f in files})==297
 report={'complete':True,'artwork_count':198,'media_count':297,'counts':manifest['counts'],'png_count':198,'gif_count':99,'all_geometry_unique':True,'all_paths_connected':True,'all_media_unique':True,'all_gifs_fully_decoded':True,'all_gifs_below_50_MB':True,'total_bytes':sum(f['bytes'] for f in files),'files':files,'geometry_checks':geometry_checks}
 (ROOT/'Validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ('files','geometry_checks')},indent=2));return report
if __name__=='__main__':validate()
