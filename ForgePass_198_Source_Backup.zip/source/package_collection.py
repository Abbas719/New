"""Package validated art into standalone GitHub-sized archives and a download index."""
from pathlib import Path
import json,zipfile,hashlib,shutil,collections
from validate_collection import validate,sha
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'packages'
BASE='https://github.com/aygaladima/New/raw/refs/heads/forge-pass-sample-download/'
LIMIT=94_000_000

def make_archive(name,records):
 path=OUT/name
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_STORED,allowZip64=False) as z:
  for rec in records:z.write(ROOT/'artwork'/rec['artifact'],rec['artifact'])
 with zipfile.ZipFile(path) as z:assert z.testzip() is None
 assert path.stat().st_size<95_000_000
 return {'filename':name,'bytes':path.stat().st_size,'sha256':sha(path),'url':BASE+name,'artworks':records}

def main():
 report=validate();OUT.mkdir(exist_ok=True)
 archives=[]
 for tier in ('Preview','Motion','Volumetric'):
  records=[f for f in report['files'] if f['tier']==tier]
  ids=sorted({f['id'] for f in records});batches=[];batch=[];size=0
  for ident in ids:
   members=[f for f in records if f['id']==ident];needed=sum(f['bytes'] for f in members)
   if batch and size+needed>LIMIT:batches.append(batch);batch=[];size=0
   batch.extend(members);size+=needed
  if batch:batches.append(batch)
  for index,batch in enumerate(batches,1):
   low=min(f['id'] for f in batch);high=max(f['id'] for f in batch)
   name=f'ForgePass_198_{tier}_{index:02d}_{low:03d}-{high:03d}.zip'
   archives.append(make_archive(name,batch));print('PACKAGED',name,flush=True)
 # A separate optional source backup keeps the art archives limited to PNG/GIF.
 source_path=OUT/'ForgePass_198_Source_Backup.zip'
 with zipfile.ZipFile(source_path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for file in sorted((ROOT/'source').glob('*.py')):z.write(file,'source/'+file.name)
  z.write(ROOT/'source'/'reference_geometry.json','source/reference_geometry.json')
  for filename in ('Collection.json','Validation.json','README.md','requirements.txt'):z.write(ROOT/filename,filename)
  for sheet in sorted((ROOT/'internal').glob('Contact_*.jpg')):z.write(sheet,'contact_sheets/'+sheet.name)
  for evidence in ('Art_Review.json','Downloader_Check.json'):
   z.write(ROOT/'internal'/evidence,'validation/'+evidence)
 source={'filename':source_path.name,'bytes':source_path.stat().st_size,'sha256':sha(source_path),'url':BASE+source_path.name}
 covered=[f['artifact'] for a in archives for f in a['artworks']];assert len(covered)==len(set(covered))==297
 manifest={'edition_size':198,'artwork_count':198,'media_count':297,'tier_counts':report['counts'],'validation_complete':True,'coverage_exactly_once':True,'artwork_bytes':report['total_bytes'],'archives':archives,'source_backup':source}
 (OUT/'Package_Manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 shutil.copyfile(ROOT/'internal'/'Collection_Overview.jpg',OUT/'ForgePass_198_Overview.jpg')
 script=(ROOT/'source'/'download_template.py').read_text().replace('ARCHIVES = []  # Replaced with the final, verified archive inventory during packaging.','ARCHIVES = '+repr(archives))
 (OUT/'ForgePass_198_Download_All.py').write_text(script)
 total=sum(a['bytes'] for a in archives)
 lines=['# Forge Pass — complete 198-artwork collection','', '**99 Preview · 66 Motion · 33 Volumetric**','',f'The full art collection contains **198 PNGs + 99 animated GIFs**, approximately **{total/1e9:.2f} GB** across {len(archives)} independent ZIP files. Every ZIP opens separately; download all art ZIPs below for the complete collection.','', '- PNG masters: 2048 × 2048 pixels.', '- GIFs: 1000 × 1000 pixels, 20 fps, infinite loop, each below 50 MB.', '- Motion: 24-second branch rotation with a counter-rotating outer ring.', '- Volumetric: 12-second separation and merging of front/rear branches, with an expanding and contracting halo.', '- The central hub stays fixed in both animated tiers.', '- Each animated artwork includes its own PNG still. Preview artworks are static.', '', '[View the collection overview](ForgePass_198_Overview.jpg)', '', '## Download the artwork','', 'Extract the ZIPs into the same folder to combine their Preview, Motion, and Volumetric folders. These are art files; no minting or publishing to OpenSea has been performed.','', '| Tier | Artwork IDs | Contents | ZIP size | Download |','|---|---|---|---|---|']
 for a in archives:
  members=a['artworks'];ids=sorted({f['id'] for f in members});tier=members[0]['tier'];counts=collections.Counter(f['format'].upper() for f in members);contents=' + '.join(f'{n} {kind}' for kind,n in counts.items())
  lines.append(f"| {tier} | {ids[0]:03d}–{ids[-1]:03d} | {contents} | {a['bytes']/1e6:.1f} MB | [Download ZIP]({a['url']}) |")
 lines += ['', '## Optional automatic download','', 'If Python 3 is installed, download [Download All](%sForgePass_198_Download_All.py), put it in the folder where you want your collection, and run `python ForgePass_198_Download_All.py`. It downloads, verifies, and extracts all 297 art files. It resumes completed artwork on later runs and removes only its own temporary ZIPs after extraction. No Python packages are required.'%BASE,'','## Optional source backup','',f"[Source, collection map, validation report, and all contact sheets]({source['url']}) ({source['bytes']/1e6:.1f} MB). This is separate from the art downloads.",'','[File checksums and full archive inventory](Package_Manifest.json)','']
 (OUT/'ForgePass_198_Downloads.md').write_text('\n'.join(lines))
 print(json.dumps({'art_archives':len(archives),'media_files':297,'bytes':total},indent=2))
if __name__=='__main__':main()
