"""Forge Pass Blender prototype. Run in Blender 4.3+ (Scripting > Run Script).

Headless: blender -b -t 4 --python build_forge.py -- --engine CYCLES --size 512 --render 61
Creates a NEW scene, preserving other scenes. Re-running creates another scene.
Only uses Blender and Python's standard library; no add-ons or pip install.
"""
import argparse
import json
import math
from pathlib import Path
import sys
import bpy
from mathutils import Vector


def arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('--engine', choices=['BLENDER_EEVEE_NEXT', 'CYCLES'], default='BLENDER_EEVEE_NEXT')
    parser.add_argument('--size', type=int, default=1000)
    parser.add_argument('--samples', type=int, default=32)
    parser.add_argument('--render', type=int, nargs='*', default=[])
    parser.add_argument('--output', default=None)
    parser.add_argument('--geometry', default='orbit_175.json')
    parser.add_argument('--label', default='B - Orbit')
    return parser.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])


def material(name, color, metallic=0.0, roughness=0.3, emission=0.0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = (*color, 1)
    p.inputs['Metallic'].default_value = metallic
    p.inputs['Roughness'].default_value = roughness
    p.inputs['Emission Color'].default_value = (*color, 1)
    p.inputs['Emission Strength'].default_value = emission
    return m


def empty(name):
    ob = bpy.data.objects.new(name, None)
    bpy.context.scene.collection.objects.link(ob)
    return ob


def curve(name, points, radius, mat, parent=None):
    c = bpy.data.curves.new(name, 'CURVE')
    c.dimensions = '3D'
    c.bevel_depth = radius
    c.bevel_resolution = 3
    c.use_fill_caps = True
    s = c.splines.new('POLY')
    s.points.add(len(points)-1)
    for point, co in zip(s.points, points):
        point.co = (*co, 1)
    ob = bpy.data.objects.new(name, c)
    bpy.context.scene.collection.objects.link(ob)
    c.materials.append(mat)
    ob.parent = parent
    return ob


def ribbon(name, points, width, mat, parent):
    points = [Vector((p[0]/100, -p[1]/100)) for p in points]
    points = [p for i,p in enumerate(points) if i == 0 or (p-points[i-1]).length > 1e-7]
    closed = (points[0]-points[-1]).length < 1e-7
    if closed:
        points.pop()
    n = len(points)
    normals = []
    for i in range(n if closed else n-1):
        d = (points[(i+1)%n]-points[i]).normalized()
        normals.append(Vector((-d.y,d.x)))
    vertices = []
    for i,p in enumerate(points):
        if not closed and i == 0:
            offset = normals[0]
        elif not closed and i == n-1:
            offset = normals[-1]
        else:
            a,b = normals[(i-1)%len(normals)],normals[i%len(normals)]
            offset = (a+b).normalized() if (a+b).length > 1e-8 else b.copy()
            offset /= max(.6,offset.dot(b))
        taper = 1 if closed else 1-.35*i/(n-1)
        offset *= width*taper/2
        for z in (0,.065):
            vertices.extend([(p.x+offset.x,p.y+offset.y,z),(p.x-offset.x,p.y-offset.y,z)])
    faces = []
    for i in range(n if closed else n-1):
        a,b=4*i,4*((i+1)%n)
        faces.extend([(a+2,a+3,b+3,b+2),(a,b,b+1,a+1),(a,a+2,b+2,b),(a+1,b+1,b+3,a+3)])
    if not closed:
        faces.extend([(0,1,3,2),(4*(n-1),4*(n-1)+2,4*(n-1)+3,4*(n-1)+1)])
    mesh=bpy.data.meshes.new(name)
    mesh.from_pydata(vertices,[],faces)
    mesh.update()
    ob=bpy.data.objects.new(name,mesh)
    bpy.context.scene.collection.objects.link(ob)
    mesh.materials.append(mat)
    ob.parent=parent
    bevel=ob.modifiers.new('Small machined edge','BEVEL')
    bevel.width=min(.012,width*.16)
    bevel.segments=3
    bevel.limit_method='ANGLE'
    ob.modifiers.new('Face normals','WEIGHTED_NORMAL')
    return ob


def cylinder(name,radius,depth,z,mat,vertices=96):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=(0,0,z))
    ob=bpy.context.object
    ob.name=name
    ob.data.materials.append(mat)
    bevel=ob.modifiers.new('Machined rim','BEVEL');bevel.width=.018;bevel.segments=3
    ob.modifiers.new('Face normals','WEIGHTED_NORMAL')
    return ob


def main():
    args=arguments()
    root=Path(__file__).resolve().parent
    out=Path(args.output).resolve() if args.output else root/'output'
    out.mkdir(parents=True,exist_ok=True)
    data=json.loads((root/args.geometry).read_text())
    scene=bpy.data.scenes.new(args.label)
    bpy.context.window.scene=scene
    scene.render.engine=args.engine
    scene.render.resolution_x=scene.render.resolution_y=args.size
    scene.render.resolution_percentage=100
    scene.render.image_settings.file_format='PNG'
    scene.render.image_settings.color_mode='RGB'
    scene.render.fps=20
    scene.frame_start=1;scene.frame_end=240
    scene.render.filepath='//frames/'+args.label.replace(' ','_')+'_'
    scene.cycles.samples=args.samples
    if hasattr(scene, 'eevee') and hasattr(scene.eevee, 'taa_render_samples'):
        scene.eevee.taa_render_samples=args.samples
    # Some Linux Blender builds omit OpenImageDenoise; keep this portable.
    scene.cycles.use_denoising=False
    scene.cycles.device='CPU'
    scene.view_settings.view_transform='AgX'
    world=bpy.data.worlds.new('Graphite studio');world.use_nodes=True
    world.node_tree.nodes['Background'].inputs[0].default_value=(.025,.04,.065,1)
    world.node_tree.nodes['Background'].inputs[1].default_value=.25
    scene.world=world
    metal=material('Electric cyan metal',(.015,.42,.62),.55,.27,.12)
    blue=material('Rear electric blue',(.008,.13,.48),.35,.32,.35)
    highlight=material('Restrained icy cyan',(.16,.72,.9),.25,.25,.55)
    dark=material('Graphite',(.006,.012,.022),.25,.4)
    backdrop=material('Matte graphite background',(.002,.004,.008),0,1)
    groups={}
    for layer in ('front','rear'):
        for a in range(len(data['angles'])):
            groups[layer,a]=empty(f'{layer} arm {a}')
    for i,p in enumerate(data['paths']):
        points=p['points']
        if p['width']>2.5 and math.hypot(*points[0])<82:
            points=[[0,0]]+points
        width=.156 if p['width']>2.5 else (.064 if p['width']>=1.7 else .029)
        ribbon(f'Front rail {i}',points,width,metal,groups['front',p['arm']])
        xy=[(x/100,-y/100,.025) for x,y in points]
        curve(f'Rear tracer {i}',xy,.018 if p['width']>2.5 else .009,blue,groups['rear',p['arm']])
        if p['width']>2.5:
            curve(f'Face inlay {i}',[(x/100,-y/100,.07) for x,y in points],.006,highlight,groups['front',p['arm']])
    halos={layer:empty(layer+' halo') for layer in ('front','rear')}
    for layer in halos:
        for i in range(10):
            pts=[(5*math.cos(math.radians(3+i*36+j*28/48)),5*math.sin(math.radians(3+i*36+j*28/48)),0) for j in range(49)]
            curve(f'{layer} halo {i}',pts,.045 if layer=='front' else .016,metal if layer=='front' else blue,halos[layer])
    cylinder('Opaque fixed hub',.82,.18,.55,dark)
    cylinder('Cyan hub collar',.66,.08,.67,metal)
    cylinder('Inset face',.57,.06,.72,dark)
    cylinder('Central hexagon',.24,.10,.79,highlight,6)
    for radius in (.72,.51,.36):
        curve('Hub precision ring',[(radius*math.cos(i*math.tau/128),radius*math.sin(i*math.tau/128),.78) for i in range(129)],.012,highlight)
    # Sample the exact periodic motion at every frame, including duplicate endpoint 241.
    # Playback/export ends at 240 so the duplicated endpoint is never exported.
    for frame in range(1,242):
        opening=.5+.5*math.sin(math.tau*(frame-1)/240)
        for (layer,arm),ob in groups.items():
            front=layer=='front'
            hinge=((-1 if arm%2==0 else 1)*(4 if front else -1))*opening
            axis=math.radians(data['angles'][arm]+hinge)
            radial=(.35 if front else .07)*opening
            scale=.78+(.19 if front else .07)*opening
            ob.location=(radial*math.cos(axis),-radial*math.sin(axis),.12+.24*opening if front else .025)
            ob.rotation_euler.z=-math.radians(hinge)
            ob.scale=(scale,scale,1)
            for prop in ('location','rotation_euler','scale'):ob.keyframe_insert(prop,frame=frame)
        for layer,ob in halos.items():
            scale=(4.05+(1.08 if layer=='front' else .43)*opening)/5
            ob.scale=(scale,scale,1)
            ob.location.z=.18+.24*opening if layer=='front' else .025
            for prop in ('location','scale'):ob.keyframe_insert(prop,frame=frame)
    for ob in list(groups.values())+list(halos.values()):
        action=ob.animation_data.action
        if hasattr(action,'fcurves'):
            curves=action.fcurves
        else:
            curves=[]
            for layer in action.layers:
                for strip in layer.strips:
                    bag=strip.channelbag(ob.animation_data.action_slot)
                    if bag:curves.extend(bag.fcurves)
        for fcurve in curves:
            for point in fcurve.keyframe_points:point.interpolation='LINEAR'
    bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.13))
    bpy.context.object.name='Graphite backdrop';bpy.context.object.data.materials.append(backdrop)
    bpy.ops.object.camera_add(location=(0,0,15))
    camera=bpy.context.object;camera.name='Orthographic production camera'
    camera.data.type='ORTHO';camera.data.ortho_scale=11.85
    scene.camera=camera
    for name,pos,power,color,size in [('Soft white key',(-3,4,7),550,(.8,.94,1),5),('Cyan fill',(4,-2,5),350,(.15,.65,1),4)]:
        light=bpy.data.lights.new(name,'AREA');light.energy=power;light.color=color;light.shape='DISK';light.size=size
        ob=bpy.data.objects.new(name,light);scene.collection.objects.link(ob);ob.location=pos
        ob.rotation_euler=(Vector((0,0,0))-ob.location).to_track_quat('-Z','Y').to_euler()
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA'
    scene['prototype_notice']='Exploratory Blender scene, not an approved replacement for collection artwork.'
    scene['source_reference']=args.geometry;scene['source_seed']=data['spec']['seed']
    if 'id' in data['spec']:scene['source_token']=data['spec']['id']
    scene.frame_set(61)
    # Verify periodic transforms before saving.
    scene.frame_set(1)
    transforms={ob.name:[list(row) for row in ob.matrix_world] for ob in list(groups.values())+list(halos.values())}
    scene.frame_set(241)
    assert all(max(abs(ob.matrix_world[i][j]-transforms[ob.name][i][j]) for i in range(4) for j in range(4))<1e-6 for ob in list(groups.values())+list(halos.values()))
    scene.frame_set(61)
    bpy.ops.wm.save_as_mainfile(filepath=str(out/(args.label.replace(' ','_')+'.blend')))
    for frame in args.render:
        scene.frame_set(frame);scene.render.filepath=str(out/(args.label.replace(' ','_')+f'_Frame_{frame:03d}.png'))
        bpy.ops.render.render(write_still=True)
    print('FORGE_READY',str(out),flush=True)


if __name__=='__main__':
    main()
