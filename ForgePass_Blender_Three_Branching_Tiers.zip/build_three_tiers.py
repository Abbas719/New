"""Build three branching examples. Run: blender -b -t 4 --python build_three_tiers.py

Self-contained Blender/Python, no external libraries. Generated files go to output/.
"""
from pathlib import Path
import json
import math
import sys
import bpy

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'
sys.path.insert(0,str(ROOT))
import build_design


def curves(action, slot):
    if hasattr(action,'fcurves'):
        return list(action.fcurves)
    result=[]
    for layer in action.layers:
        for strip in layer.strips:
            bag=strip.channelbag(slot)
            if bag:result.extend(bag.fcurves)
    return result


def snapshot(scene,frame):
    scene.frame_set(frame)
    return {o.name:[list(row) for row in o.matrix_world] for o in scene.objects}


def difference(a,b):
    return max(abs(a[name][i][j]-b[name][i][j]) for name in a for i in range(4) for j in range(4))


scenes=[]
reports={}
for tier,label in [('Preview','01 - Preview'),('Motion','02 - Motion'),('Volumetric','03 - Volumetric')]:
    sys.argv=['blender','--','--geometry','branching_reference.json','--label',label,'--size','1000','--samples','32']
    build_design.main()
    scene=bpy.context.scene
    scenes.append(scene)
    scene.frame_set(61)
    if tier!='Volumetric':
        # Freeze the fully open front design, remove the rear layer entirely.
        for ob in list(scene.objects):
            if ob.animation_data:ob.animation_data_clear()
        rear=[o for o in scene.objects if o.type=='EMPTY' and o.name.startswith('rear')]
        for parent in rear:
            for child in list(parent.children):bpy.data.objects.remove(child,do_unlink=True)
            bpy.data.objects.remove(parent,do_unlink=True)
        scene.frame_end=1 if tier=='Preview' else 480
        if tier=='Motion':
            rotor=build_design.empty('Clockwise branch assembly')
            for ob in list(scene.objects):
                if ob.type=='EMPTY' and ob.name.startswith('front arm'):
                    ob.parent=rotor
            halo=next(o for o in scene.objects if o.type=='EMPTY' and o.name.startswith('front halo'))
            for ob,turn in [(rotor,-math.tau),(halo,math.tau)]:
                ob.rotation_euler.z=0
                ob.keyframe_insert('rotation_euler',index=2,frame=1)
                ob.rotation_euler.z=turn
                ob.keyframe_insert('rotation_euler',index=2,frame=481)
                for curve in curves(ob.animation_data.action,getattr(ob.animation_data,'action_slot',None)):
                    for point in curve.keyframe_points:point.interpolation='LINEAR'
    scene['tier_example']=tier
    scene['design_reference']='Approved five-arm branching sample; example only, no NFT token reassigned.'
    scene.render.filepath='//frames/'+tier+'_'
    scene.timeline_markers.clear()
    if tier=='Volumetric':
        for name,frame in [('Half open',1),('OPEN',61),('Half closed',121),('CLOSED',181)]:
            scene.timeline_markers.new(name,frame=frame)
    elif tier=='Motion':
        for name,frame in [('START',1),('Quarter turn',121),('Half turn',241),('Three-quarter turn',361)]:
            scene.timeline_markers.new(name,frame=frame)
    start=snapshot(scene,1)
    end=snapshot(scene,scene.frame_end+1)
    loop_error=difference(start,end)
    assert loop_error<1e-5,(tier,loop_error)
    if tier=='Preview':
        assert not any(o.animation_data and o.animation_data.action for o in scene.objects)
        assert difference(start,snapshot(scene,181))==0
    else:
        assert difference(start,snapshot(scene,121 if tier=='Motion' else 61))>.05
    hubs=[o.name for o in scene.objects if o.name.startswith(('Opaque fixed hub','Central hexagon','Cyan hub collar'))]
    probe=snapshot(scene,121 if tier=='Motion' else 181)
    assert all(start[name]==probe[name] for name in hubs)
    if tier=='Motion':
        scene.frame_set(121)
        assert abs(rotor.rotation_euler.z+math.pi/2)<1e-5
        assert abs(halo.rotation_euler.z-math.pi/2)<1e-5
    scene.frame_set(61 if tier=='Volumetric' else 1)
    reports[tier]={'fps':20,'frames':[1,scene.frame_end],'duration_seconds':0 if tier=='Preview' else scene.frame_end/20,'loop_transform_max_error':loop_error,'fixed_hub_check':'passed','animated_objects':sum(bool(o.animation_data and o.animation_data.action) for o in scene.objects)}

for scene in list(bpy.data.scenes):
    if scene not in scenes:bpy.data.scenes.remove(scene)
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            space=area.spaces.active
            space.region_3d.view_perspective='CAMERA'
            space.region_3d.view_camera_zoom=0
            space.overlay.show_overlays=False
            space.shading.type='SOLID'
            space.shading.color_type='MATERIAL'
bpy.context.window.scene=scenes[0]
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'ForgePass_Branches_Three_Tiers.blend'))
(OUT/'Validation.json').write_text(json.dumps(reports,indent=2)+'\n')
for scene,frames in [(scenes[0],[1]),(scenes[1],[1,121])]:
    bpy.context.window.scene=scene
    for frame in frames:
        scene.frame_set(frame)
        scene.render.filepath=str(OUT/(scene['tier_example']+f'_Frame_{frame:03d}.png'))
        bpy.ops.render.render(write_still=True)
print('THREE_TIERS_READY',flush=True)
