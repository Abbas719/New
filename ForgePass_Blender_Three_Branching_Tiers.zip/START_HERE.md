# Forge Pass — three branching examples in Blender

## Open the examples

1. Extract this ZIP.
2. In Blender choose File > Open and select `ForgePass_Branches_Three_Tiers.blend`.
3. Use the scene selector at the top of Blender to choose one of the three scenes below. Click the scene icon/dropdown beside the current scene name if needed.

| Scene | What you will see | Timeline |
|---|---|---|
| 01 - Preview | Static branching composition. No animated objects or rear duplicate branches. | Frame 1 only |
| 02 - Motion | Front branches turn clockwise; outer ring turns counterclockwise; hub stays fixed. One gentle turn in 24 seconds. | Frames 1–480 at 20 fps |
| 03 - Volumetric | Front and rear branches slowly separate and merge, with an expanding/contracting halo; hub stays fixed. A 12-second loop. | Frames 1–240 at 20 fps |

## Play and inspect

- Press Numpad 0 for the camera view if necessary. Without a number pad, use View > Cameras > Active Camera.
- Hover over the 3D view and press Z > Rendered to see the final materials and lighting. Allow time for shaders to compile.
- Hover over the Timeline and press Space to play/pause Motion or Volumetric. Slow viewport performance can skip frames; it is not an encoded animation file.
- Press F12 to render the current frame. F11 returns from the render window.
- For Motion, compare frames 1 and 121 (quarter turn), or 241 (half turn).
- For Volumetric, compare frame 61 (open) with 181 (closed).
- Preview intentionally stays still. It has a one-frame timeline.

The default Solid viewport uses material colours for easier navigation, but is not the final lighting. PNG stills are also included for reference.

## What is consistent

All examples use the same approved five-arm branching source geometry, cyan materials, camera scale, hub, lighting, and graphite background. Preview and Motion omit the blue rear branch layer so Volumetric's depth treatment remains distinct. This package compares tier behaviours, not three randomly different designs. No NFT token IDs or collection metadata were changed.

## Verification and limits

Built in Blender 4.3.2. Static invariance, opposite Motion rotation, fixed hubs, and matching loop endpoint transforms were checked. Motion's duplicated endpoint is frame 481; Volumetric's is 241. These endpoint frames are outside their export ranges so playback does not pause on a duplicate frame.

The new Preview and Motion reference stills were rendered at 1000 × 1000. Volumetric stills are reused from the previous tested branching scene, whose geometry, materials and animation are unchanged. This package contains editable animated scenes and stills, not final GIFs or an exported full animation. Final GIF palette, temporal rendering and file-size checks remain for production.

## Optional rebuilding

Opening and playing the `.blend` needs no add-ons or separate Python installation. To reproduce the scenes, keep `build_three_tiers.py`, `build_design.py`, and `branching_reference.json` together and run:

    blender -b -t 4 --python build_three_tiers.py

The combined scene and renders are generated under `output/`. Only the combined `ForgePass_Branches_Three_Tiers.blend` is the final three-tier deliverable; any individual scene saves created during the build are intermediate construction files.
