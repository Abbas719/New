# Forge Pass — Blender starter

This is an exploratory Volumetric prototype using the existing Orbit #175 geometry. It does not replace or modify the 198-piece collection. The geometry and source seed are preserved; the prototype uses a cyan/blue material treatment instead of the original rose palette.

## Open and inspect — no coding required

1. Install Blender from https://www.blender.org/download/ if needed. This package was tested with Blender 4.3.2; newer versions have not been verified here.
2. Extract the entire ZIP to a normal folder on your computer.
3. In Blender choose File > Open and open `ForgePass_Orbit175_Prototype.blend` from that folder.
4. Press Numpad 0 to enter the camera view if needed. On a laptop use View > Cameras > Active Camera.
5. Press Z and choose Rendered to see the materials and scene lighting. Allow shaders to compile. Solid shading is faster but does not show the final material colours.
6. Move the mouse over the Timeline and press Space to play or pause. The scene has 240 frames at 20 fps: a 12-second opening-and-closing loop. Viewport playback can run slower or skip frames on limited hardware; this is not a rendered GIF.
7. Set the current frame to 61 for the open pose, or 181 for the closed pose. Press F12 to render that pose. Press F11 to return from the render window.

The included `Blender_Frame_061.png` and `Blender_Frame_181.png` show actual 1000 × 1000 renders from this scene. `Legacy_Cyan_Frame_060.png` and `Legacy_Cyan_Frame_180.png` show the original renderer's corresponding poses with cyan selected for comparison. Blender frames begin at 1; the original renderer begins at 0. Materials and depth differ deliberately, so this is an artistic prototype comparison, not an isolated renderer benchmark.

## What is already set up

- Original procedural Orbit paths, imported as shallow beveled rails.
- Electric-cyan front structures, a thinner blue rear layer, a fixed central hub.
- Orthographic camera, matte graphite backdrop, two area lights.
- Per-frame baked transformations: separation, arm hinging, expansion, and merging.
- Eevee renderer, 1000 × 1000 PNG output, 32 render samples.
- Frame 241 duplicates frame 1 for endpoint verification; export ends at frame 240.
- No external textures, add-ons, paid services, or runtime Python scripts needed for scene playback.

## Rebuild with Python inside Blender

The supplied `.blend` is ready to open; this section is optional.

1. Keep `build_forge.py` and `orbit_175.json` together.
2. Open Blender's Scripting workspace.
3. In the Text Editor choose Open and select `build_forge.py`.
4. Click Run Script. It creates and selects a new scene, preserving other scenes.
5. The generated project is saved under `output/` beside the script. Re-running creates another scene; use a fresh Blender session for a clean rebuild.

No separate Python, NumPy, Pillow, or FFmpeg installation is needed for this builder.

For command-line users with Blender on PATH:

```sh
blender -b -t 4 --python build_forge.py -- --engine BLENDER_EEVEE_NEXT --size 1000 --samples 32 --render 61 181
```

For a CPU Cycles experiment, use `--engine CYCLES`. Denoising is disabled for compatibility with Blender builds that omit OpenImageDenoise. Cycles render quality and speed have not been approved by this prototype test.

## Next decision

Review the open/closed poses and interactive movement first. Confirm the geometry, cyan materials, depth, and lighting before spending time rendering the complete animation. Then render a lossless PNG sequence and encode/test a global-palette GIF under the marketplace size limit. No final GIF, MP4, or complete collection rebuild is included in this starter.

Do not assume these Blender stills prove superiority over the previous renderer. Full animation quality, GIF palette behaviour, encoding size, and production performance still need testing. Hardware-specific settings should be selected after identifying your GPU and RAM.
