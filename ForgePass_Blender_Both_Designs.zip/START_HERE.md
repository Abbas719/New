# Compare both Forge Pass designs in Blender

1. Extract this ZIP.
2. In Blender choose File > Open and open `ForgePass_Compare_Branching_and_Orbit.blend`.
3. The file opens with scene **A - Branching** selected. This uses the five-arm branching geometry from the earlier approved Volumetric sample.
4. Leave the timeline at frame **61** and press **F12** to render the open pose. Use F11 to return from the render window.
5. At the top of Blender, find the scene selector showing **A - Branching**. Click its scene dropdown and select **B - Orbit**. This is the seven-arm oval design you have already seen.
6. Leave frame **61** selected and press **F12** again to compare the same animation pose.
7. To compare the closed pose, set frame **181** in each scene and render.
8. To play either design, move the pointer over the Timeline and press Space. For materials in the viewport, hover over the 3D view and press Z > Rendered. The default Solid viewport is faster but is not the final shading.

Both scenes use the same camera scale, lights, materials, hub treatment, background, resolution (1000 square), and 12-second/20-fps animation settings. They are separate scenes, so they never render over one another. The animations use baked keyframes; no add-ons or Python installation are needed to open or play the project.

The branching sample has been translated into the same Blender rail/material treatment as Orbit. This preserves its branching paths and seed, but it is not a pixel-identical reconstruction of every decorative detail in the older 2D renderer. No collection IDs were reassigned. Branching is identified as a reference sample, not a newly assigned NFT token.

Included PNGs show the open and closed poses of both designs. Branching was rendered for this comparison; Orbit's images are copied unchanged from the tested starter, using identical rendering settings. These are still-image checks, not a completed GIF comparison.

The project was built and checked in Blender 4.3.2. The previous Orbit file opened and rendered on your Blender 5.2.2; this combined file still needs its local opening check.

Optional reproducible build: keep the two JSON geometry files and two Python scripts together, then run:

    blender -b -t 4 --python build_comparison.py

This creates the two-scene project and renders the branching poses under output/. The Python builder does not need external libraries. No existing collection files are modified.
