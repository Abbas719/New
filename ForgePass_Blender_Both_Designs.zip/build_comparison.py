"""Run with Blender: blender -b -t 4 --python build_comparison.py

Creates two independent scenes in one portable .blend. Renders the branching
open/closed poses. Orbit uses the identical previous prototype geometry/style.
"""
import json
from pathlib import Path
import sys
import bpy

root=Path(__file__).resolve().parent
sys.path.insert(0,str(root))
import build_design

for geometry,label,renders in [('orbit_175.json','B - Orbit',[]),('branching_reference.json','A - Branching',['61','181'])]:
    sys.argv=['blender','--','--geometry',geometry,'--label',label,'--size','1000','--samples','32','--render']+renders
    build_design.main()

scenes=[bpy.data.scenes['A - Branching'],bpy.data.scenes['B - Orbit']]
for scene in list(bpy.data.scenes):
    if scene not in scenes:
        bpy.data.scenes.remove(scene)
report={}
for scene in scenes:
    bpy.context.window.scene=scene
    scene.render.filepath='//frames/'+scene.name.replace(' ','_')+'_'
    moving=[o for o in scene.objects if o.animation_data and o.animation_data.action]
    scene.frame_set(1)
    first={o.name:[list(row) for row in o.matrix_world] for o in moving}
    scene.frame_set(241)
    delta=max(abs(o.matrix_world[i][j]-first[o.name][i][j]) for o in moving for i in range(4) for j in range(4))
    assert delta<1e-6
    scene.frame_set(61)
    report[scene.name]={'objects':len(scene.objects),'animated_objects':len(moving),'loop_transform_max_error':delta,'resolution':[scene.render.resolution_x,scene.render.resolution_y],'frames':[scene.frame_start,scene.frame_end],'fps':scene.render.fps}
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type=='VIEW_3D':
                area.spaces.active.region_3d.view_perspective='CAMERA'
                area.spaces.active.region_3d.view_camera_zoom=0
                area.spaces.active.overlay.show_overlays=False
                area.spaces.active.shading.type='SOLID'
bpy.context.window.scene=scenes[0]
bpy.ops.wm.save_as_mainfile(filepath=str(root/'output'/'ForgePass_Compare_Branching_and_Orbit.blend'))
(root/'output'/'Scene_Checks.json').write_text(json.dumps(report,indent=2)+'\n')
print('COMPARISON_READY',flush=True)
